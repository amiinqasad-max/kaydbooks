/**
 * Supabase Service for Admin Web Panel
 */

class SupabaseService {
    constructor() {
        this.supabase = null;
        this.bucketName = 'books';
        this.init();
    }

    init() {
        try {
            // Check if Supabase library is loaded
            if (!window.supabase) {
                throw new Error('Supabase library not loaded. Check your internet connection.');
            }

            // Try service role key first (bypasses RLS)
            if (window.SUPABASE_CONFIG_SERVICE && window.SUPABASE_CONFIG_SERVICE.serviceKey && 
                window.SUPABASE_CONFIG_SERVICE.serviceKey !== 'YOUR_SERVICE_ROLE_KEY_HERE') {
                
                const { url, serviceKey } = window.SUPABASE_CONFIG_SERVICE;
                this.supabase = window.supabase.createClient(url, serviceKey);
                this.bucketName = window.SUPABASE_CONFIG_SERVICE.bucketName || 'books';
                console.log('✅ Supabase initialized with SERVICE ROLE (bypasses RLS)');
                return true;
            }

            // Fallback to regular config
            if (!window.SUPABASE_CONFIG) {
                throw new Error('Supabase configuration not found. Please check config.js');
            }

            const { url, anonKey } = window.SUPABASE_CONFIG;
            
            // Check if config values are set
            if (!url || url === 'YOUR_SUPABASE_URL_HERE') {
                throw new Error('Please set your Supabase URL in config.js');
            }
            
            if (!anonKey || anonKey === 'YOUR_SUPABASE_ANON_KEY_HERE') {
                throw new Error('Please set your Supabase anon key in config.js');
            }

            this.supabase = window.supabase.createClient(url, anonKey);
            this.bucketName = window.SUPABASE_CONFIG.bucketName || 'books';
            
            console.log('✅ Supabase initialized with ANON KEY (may have RLS restrictions)');
            console.warn('⚠️ If you get RLS errors, use SERVICE ROLE key in config_service.js');
            return true;
        } catch (error) {
            console.error('❌ Supabase initialization failed:', error.message);
            this.showInitError(error.message);
            return false;
        }
    }

    showInitError(message) {
        // Create error display if Supabase fails to initialize
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = `
            position: fixed; top: 0; left: 0; right: 0; 
            background: #ef4444; color: white; padding: 1rem; 
            text-align: center; z-index: 9999; font-weight: bold;
        `;
        errorDiv.innerHTML = `
            <strong>⚠️ Configuration Error:</strong> ${message}
            <br><small>Please check the setup instructions in README.md</small>
        `;
        document.body.insertBefore(errorDiv, document.body.firstChild);
    }

    sanitizeBookRecord(book) {
        if (!book) return this.getEmptyBookRecord();
        return {
            id: book.id || '',
            title: book.title || '',
            author: book.author || '',
            description: book.description || '',
            category: book.category || 'General',
            cover_url: book.cover_url || '',
            pdf_url: book.pdf_url || '',
            audio_url: book.audio_url || '',
            created_at: book.created_at || new Date().toISOString()
        };
    }

    getEmptyBookRecord() {
        return {
            id: '', title: '', author: '', description: '', category: 'General',
            cover_url: '', pdf_url: '', audio_url: '',
            created_at: new Date().toISOString()
        };
    }

    detectMimeType(file) {
        const ext = file.name.split('.').pop().toLowerCase();
        const mimeMap = {
            'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
            'pdf': 'application/pdf', 'mp3': 'audio/mpeg', 'wav': 'audio/wav'
        };
        return mimeMap[ext] || 'application/octet-stream';
    }

    async uploadFile(file, folder = '') {
        const timestamp = Date.now();
        const randomId = Math.random().toString(36).substring(2, 15);
        const extension = file.name.split('.').pop();
        const filename = `${folder ? folder + '/' : ''}${timestamp}_${randomId}.${extension}`;
        const mimeType = this.detectMimeType(file);

        const { data, error } = await this.supabase.storage
            .from(this.bucketName)
            .upload(filename, file, { contentType: mimeType });

        if (error) throw new Error(`Upload failed: ${error.message}`);
        return data.path;
    }

    getPublicUrl(filePath) {
        const { data } = this.supabase.storage.from(this.bucketName).getPublicUrl(filePath);
        return data.publicUrl;
    }

    async createBook(bookData) {
        const safeData = {
            title: bookData.title?.trim() || '',
            author: bookData.author?.trim() || '',
            description: bookData.description?.trim() || '',
            category: bookData.category || 'General',
            cover_url: bookData.cover_url || null,
            pdf_url: bookData.pdf_url || null,
            audio_url: bookData.audio_url || null,
            created_at: new Date().toISOString()
        };

        const { data, error } = await this.supabase
            .from('books')
            .insert([safeData])
            .select();

        if (error) throw new Error(`Database error: ${error.message}`);
        return this.sanitizeBookRecord(data[0]);
    }

    async getBooks() {
        const { data, error } = await this.supabase
            .from('books')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw new Error(`Database error: ${error.message}`);
        return (data || []).map(book => this.sanitizeBookRecord(book));
    }

    async updateBook(id, bookData) {
        const safeData = {
            title: bookData.title?.trim() || '',
            author: bookData.author?.trim() || '',
            description: bookData.description?.trim() || '',
            category: bookData.category || 'General'
        };

        const { data, error } = await this.supabase
            .from('books')
            .update(safeData)
            .eq('id', id)
            .select();

        if (error) throw new Error(`Database error: ${error.message}`);
        return this.sanitizeBookRecord(data[0]);
    }

    async deleteBook(id) {
        try {
            console.log(`🗑️ Deleting book ${id}...`);

            // First get the book to find file paths
            const { data: bookData, error: fetchError } = await this.supabase
                .from('books')
                .select('*')
                .eq('id', id)
                .single();

            if (fetchError) {
                console.error('Failed to fetch book for deletion:', fetchError);
                // Continue with deletion even if we can't fetch the book
            }

            // Delete files from storage if book data was found
            if (bookData) {
                const filesToDelete = [];
                
                // Extract file paths from URLs
                if (bookData.cover_url) {
                    const coverPath = this.extractPathFromUrl(bookData.cover_url);
                    if (coverPath) filesToDelete.push(coverPath);
                }
                
                if (bookData.pdf_url) {
                    const pdfPath = this.extractPathFromUrl(bookData.pdf_url);
                    if (pdfPath) filesToDelete.push(pdfPath);
                }
                
                if (bookData.audio_url) {
                    const audioPath = this.extractPathFromUrl(bookData.audio_url);
                    if (audioPath) filesToDelete.push(audioPath);
                }

                // Delete files from storage
                if (filesToDelete.length > 0) {
                    console.log(`📁 Deleting ${filesToDelete.length} files from storage...`);
                    const { error: storageError } = await this.supabase.storage
                        .from(this.bucketName)
                        .remove(filesToDelete);

                    if (storageError) {
                        console.warn('⚠️ Some files could not be deleted from storage:', storageError.message);
                        // Don't throw error, continue with database deletion
                    } else {
                        console.log('✅ Files deleted from storage');
                    }
                }
            }

            // Delete book record from database
            const { error: deleteError } = await this.supabase
                .from('books')
                .delete()
                .eq('id', id);

            if (deleteError) {
                throw new Error(`Failed to delete book from database: ${deleteError.message}`);
            }

            console.log('✅ Book deleted successfully from database');
            return true;
        } catch (error) {
            console.error('❌ Delete book error:', error);
            throw error;
        }
    }

    /**
     * Extract file path from Supabase public URL
     */
    extractPathFromUrl(url) {
        if (!url) return null;
        
        try {
            // Handle both old and new Supabase URL formats
            const patterns = [
                `/storage/v1/object/public/${this.bucketName}/`,
                `/storage/v1/object/sign/${this.bucketName}/`,
                `/${this.bucketName}/`
            ];
            
            for (const pattern of patterns) {
                if (url.includes(pattern)) {
                    const parts = url.split(pattern);
                    if (parts.length > 1) {
                        // Remove query parameters if any
                        return parts[1].split('?')[0];
                    }
                }
            }
            
            console.warn('⚠️ Could not extract path from URL:', url);
            return null;
        } catch (error) {
            console.warn('⚠️ Error extracting path from URL:', url, error);
            return null;
        }
    }
}

window.supabaseService = new SupabaseService();
