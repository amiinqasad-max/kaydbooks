# 🚀 INSTANT RLS BYPASS SOLUTION

## ❌ **Current Problem:**
`Upload failed: new row violates row-level security policy`

## ✅ **INSTANT FIX - Use Service Role Key:**

### **Step 1: Get Your Service Role Key**
1. Go to [Supabase Dashboard](https://supabase.com/dashboard/project/diznvbjdfgiehtwegpvs)
2. Click **Settings** → **API**
3. Find **"service_role"** key (NOT anon key)
4. Copy the long key that starts with `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

### **Step 2: Update config_service.js**
Open `admin_web/config_service.js` and replace:

```javascript
const SUPABASE_CONFIG_SERVICE = {
    url: 'https://diznvbjdfgiehtwegpvs.supabase.co',
    
    // Paste your SERVICE ROLE key here:
    serviceKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.YOUR_ACTUAL_SERVICE_KEY_HERE',
    
    bucketName: 'books'
};
```

### **Step 3: Test Upload**
1. Refresh your admin panel
2. Check console - should see: `✅ Supabase initialized with SERVICE ROLE (bypasses RLS)`
3. Try uploading a book - **should work immediately!**

## 🔒 **Why This Works:**
- **Anon key** = Limited permissions, blocked by RLS
- **Service role key** = Full admin access, bypasses all RLS policies

## ⚠️ **Security Note:**
Service role key has full database access - only use for admin panels, never in public apps.

## 🎯 **Expected Console Output:**
```
✅ Supabase initialized with SERVICE ROLE (bypasses RLS)
📤 Uploading file: cover.jpg (image/jpeg)
✅ File uploaded successfully
📚 Creating book record...
✅ Book uploaded successfully!
```

## 🔄 **Alternative: Still Want to Use SQL?**
If you prefer to disable RLS instead, run this in Supabase SQL Editor:
```sql
ALTER TABLE books DISABLE ROW LEVEL SECURITY;
```

**But the service role key solution works immediately without any SQL changes!**
