/**
 * Alternative Supabase Configuration using Service Role Key
 * This bypasses Row Level Security for admin operations
 * 
 * IMPORTANT: Get your SERVICE ROLE KEY (not anon key) from Supabase Dashboard
 */

const SUPABASE_CONFIG_SERVICE = {
    // Your Supabase URL (same as before)
    url: 'https://diznvbjdfgiehtwegpvs.supabase.co',
    
    // Replace with your SERVICE ROLE KEY (bypasses RLS)
    // Go to Settings > API > Copy "service_role" key (NOT anon key)
    serviceKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpem52YmpkZmdpZWh0d2VncHZzIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MjA5MjgxOCwiZXhwIjoyMDc3NjY4ODE4fQ.H2xI4Jf-NCTxyKSQnQ-ezNxoakPbYBGfmMslJbNC8Gk',
    
    // Storage bucket name for books
    bucketName: 'books'
};

// Export configuration
window.SUPABASE_CONFIG_SERVICE = SUPABASE_CONFIG_SERVICE;

/**
 * HOW TO GET SERVICE ROLE KEY:
 * 
 * 1. Go to Supabase Dashboard > Settings > API
 * 2. Find "service_role" key (NOT anon key)
 * 3. Copy the long key that starts with "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 * 4. Replace 'YOUR_SERVICE_ROLE_KEY_HERE' above
 * 
 * WARNING: Service role key has full database access - only use for admin panels!
 */
