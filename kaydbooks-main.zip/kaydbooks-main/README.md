# Book Reader & Audiobook App

A complete React Native (Expo SDK 51) mobile application for reading books and listening to audiobooks, powered by Supabase backend.

## Features

- **Authentication**: Email/password signup, login, logout with Supabase Auth
- **Admin Dashboard**: Upload books with cover images, PDF files, and audio files
- **Book Library**: Browse all uploaded books with search functionality
- **PDF Reader**: Read books using react-native-pdf viewer
- **Audio Player**: Listen to audiobooks with expo-av player
- **Real Data**: All content comes from Supabase database and storage (no demo data)

## Prerequisites

- Node.js (v16 or higher)
- Expo CLI (`npm install -g @expo/cli`)
- Supabase account and project

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Supabase Setup

1. Create a new project at [supabase.com](https://supabase.com)
2. Go to Settings > API to get your project URL and anon key
3. Update the `.env` file with your Supabase credentials:

```env
EXPO_PUBLIC_SUPABASE_URL=your_supabase_project_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

4. Also update `services/supabase.js` with the same credentials

### 3. Database Schema

Run these SQL commands in your Supabase SQL editor:

```sql
-- Enable RLS
ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

-- Create profiles table
CREATE TABLE profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE,
  email TEXT,
  name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  PRIMARY KEY (id)
);

-- Create books table
CREATE TABLE books (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  cover_url TEXT NOT NULL,
  pdf_url TEXT NOT NULL,
  audio_url TEXT NOT NULL,
  uploaded_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE books ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

-- Books policies
CREATE POLICY "Anyone can view books" ON books
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can insert books" ON books
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');
```

### 4. Storage Setup

1. Go to Storage in your Supabase dashboard
2. Create a new bucket called `books`
3. Set the bucket to public
4. Add the following storage policies:

```sql
-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload files" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'books' AND auth.role() = 'authenticated');

-- Allow public access to view files
CREATE POLICY "Public access to view files" ON storage.objects
  FOR SELECT USING (bucket_id = 'books');
```

### 5. Admin Access

To access admin features, create an account with email: `admin@bookapp.com`

## Running the App

```bash
# Start the development server
npm start

# Run on Android
npm run android

# Run on iOS
npm run ios

# Run on web
npm run web
```

## Project Structure

```
├── screens/              # App screens
│   ├── LoginScreen.js
│   ├── SignUpScreen.js
│   ├── HomeScreen.js
│   ├── BookDetailScreen.js
│   ├── PDFViewerScreen.js
│   └── AudioPlayerScreen.js
├── admin/                # Admin screens
│   └── AdminUploadScreen.js
├── contexts/             # React contexts
│   └── AuthContext.js
├── services/             # API services
│   └── supabase.js
├── App.js               # Main app component
└── package.json         # Dependencies
```

## Usage

### For Users
1. Sign up or login with your credentials
2. Browse the book library on the home screen
3. Search for books by title or author
4. Tap on a book to view details
5. Read the PDF or listen to the audiobook

### For Admins
1. Login with admin credentials (`admin@bookapp.com`)
2. Tap "Admin: Upload Book" on the home screen
3. Fill in book details and select files:
   - Cover image (JPG/PNG)
   - PDF file
   - Audio file (MP3/M4A)
4. Upload the book

## Dependencies

- **expo**: ~54.0.0
- **react-native**: 0.76.3
- **@supabase/supabase-js**: ^2.39.0
- **react-native-pdf**: ^6.7.3
- **expo-av**: ~15.0.1
- **react-native-elements**: ^3.4.3
- **@react-navigation/native**: ^6.1.9

## Testing

1. Upload a real book using the admin interface
2. Verify the book appears in the home screen
3. Test PDF reading functionality
4. Test audio playback functionality
5. Test search and filtering

## Troubleshooting

### PDF not loading
- Ensure the PDF file is properly uploaded to Supabase Storage
- Check that the storage bucket is public
- Verify the PDF URL is accessible

### Audio not playing
- Ensure audio file format is supported (MP3, M4A, WAV)
- Check Supabase Storage permissions
- Verify audio URL is accessible

### Upload failing
- Check Supabase Storage policies
- Ensure file sizes are within limits
- Verify internet connection

## License

MIT License
# kayd
# kayd
# kaydbooks
