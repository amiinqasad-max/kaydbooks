import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
  Modal,
} from 'react-native';
import { Text } from 'react-native';
import { Button, Searchbar, Appbar } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';
import CustomHeader from '../components/CustomHeader';
import {
  getBooks,
  searchBooks,
  getBooksByCategory,
  getCategories,
  addToFavorites,
  removeFromFavorites,
  isFavorite,
} from '../services/supabase';

const ExploreScreen = ({ navigation }) => {
  const { user } = useAuth();
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  const [randomPicks, setRandomPicks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [authors, setAuthors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedAuthor, setSelectedAuthor] = useState('All');
  const [sortBy, setSortBy] = useState('latest');
  const [showFilters, setShowFilters] = useState(false);
  const [favorites, setFavorites] = useState({});
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const ITEMS_PER_PAGE = 10;

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [books, selectedCategory, selectedAuthor, sortBy, searchQuery]);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      const [booksData, categoriesData] = await Promise.all([
        getBooks(),
        getCategories(),
      ]);

      setBooks(booksData);
      setCategories(['All', ...categoriesData]);
      
      // Extract unique authors
      const uniqueAuthors = ['All', ...new Set(booksData.map(book => book.author))];
      setAuthors(uniqueAuthors);

      // Get random picks (3 random books)
      const shuffled = [...booksData].sort(() => 0.5 - Math.random());
      setRandomPicks(shuffled.slice(0, 3));

      // Load favorites status
      if (user) {
        const favoritesStatus = {};
        await Promise.all(
          booksData.map(async (book) => {
            const isFav = await isFavorite(user.id, book.id);
            favoritesStatus[book.id] = isFav;
          })
        );
        setFavorites(favoritesStatus);
      }

      setPage(1);
      setHasMore(true);
    } catch (error) {
      console.error('Error loading explore data:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...books];

    // Apply search filter
    if (searchQuery.trim()) {
      filtered = filtered.filter(book =>
        book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        book.author.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply category filter
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(book => book.category === selectedCategory);
    }

    // Apply author filter
    if (selectedAuthor !== 'All') {
      filtered = filtered.filter(book => book.author === selectedAuthor);
    }

    // Apply sorting
    switch (sortBy) {
      case 'latest':
        filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        break;
      case 'oldest':
        filtered.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
        break;
      case 'title':
        filtered.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'author':
        filtered.sort((a, b) => a.author.localeCompare(b.author));
        break;
      default:
        break;
    }

    setFilteredBooks(filtered);
    setPage(1);
    setHasMore(filtered.length > ITEMS_PER_PAGE);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadInitialData();
    setRefreshing(false);
  };

  const loadMore = () => {
    if (hasMore && !loading) {
      const nextPage = page + 1;
      const startIndex = (nextPage - 1) * ITEMS_PER_PAGE;
      const endIndex = startIndex + ITEMS_PER_PAGE;
      
      if (startIndex < filteredBooks.length) {
        setPage(nextPage);
        setHasMore(endIndex < filteredBooks.length);
      } else {
        setHasMore(false);
      }
    }
  };

  const toggleFavorite = async (bookId) => {
    if (!user) {
      navigation.navigate('Login');
      return;
    }

    try {
      const currentlyFavorite = favorites[bookId];
      
      if (currentlyFavorite) {
        await removeFromFavorites(user.id, bookId);
      } else {
        await addToFavorites(user.id, bookId);
      }
      
      setFavorites(prev => ({
        ...prev,
        [bookId]: !currentlyFavorite
      }));
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const resetFilters = () => {
    setSelectedCategory('All');
    setSelectedAuthor('All');
    setSortBy('latest');
    setSearchQuery('');
  };

  const renderBookItem = ({ item }) => (
    <TouchableOpacity
      style={styles.bookItem}
      onPress={() => navigation.navigate('BookDetail', { book: item })}
    >
      <Image source={{ uri: item.cover_url }} style={styles.bookCover} />
      <View style={styles.bookInfo}>
        <Text style={styles.bookTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.bookAuthor} numberOfLines={1}>
          by {item.author}
        </Text>
        <Text style={styles.bookCategory}>{item.category}</Text>
        {item.pages && (
          <Text style={styles.bookPages}>{item.pages} pages</Text>
        )}
        <View style={styles.bookActions}>
          <Button
            title="Read"
            buttonStyle={[styles.actionBtn, styles.readBtn]}
            titleStyle={styles.actionBtnText}
            onPress={() => navigation.navigate('PDFViewer', { book: item })}
          />
          {item.audio_url && (
            <Button
              title="Listen"
              buttonStyle={[styles.actionBtn, styles.listenBtn]}
              titleStyle={styles.actionBtnText}
              onPress={() => navigation.navigate('AudioPlayer', { book: item })}
            />
          )}
        </View>
      </View>
      <TouchableOpacity
        style={styles.favoriteBtn}
        onPress={() => toggleFavorite(item.id)}
      >
        <MaterialCommunityIcons
          name={favorites[item.id] ? "heart" : "heart-outline"}
          size={24}
          color={favorites[item.id] ? "#FF6B6B" : "#CCC"}
        />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const renderRandomPick = ({ item }) => (
    <TouchableOpacity
      style={styles.randomPickItem}
      onPress={() => navigation.navigate('BookDetail', { book: item })}
    >
      <Image source={{ uri: item.cover_url }} style={styles.randomPickCover} />
      <View style={styles.randomPickInfo}>
        <Text style={styles.randomPickTitle} numberOfLines={1}>
          {item.title}
        </Text>
        <Text style={styles.randomPickAuthor} numberOfLines={1}>
          {item.author}
        </Text>
      </View>
    </TouchableOpacity>
  );

  const renderFilterModal = () => (
    <Modal
      visible={showFilters}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowFilters(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Filters & Sort</Text>
            <TouchableOpacity onPress={() => setShowFilters(false)}>
              <MaterialCommunityIcons name="close" size={24} color={COLORS.TEXT} />
            </TouchableOpacity>
          </View>

          {/* Category Filter */}
          <View style={styles.filterSection}>
            <Text style={styles.filterLabel}>Category</Text>
            <FlatList
              data={categories}
              horizontal
              showsHorizontalScrollIndicator={false}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.filterChip,
                    selectedCategory === item && styles.activeFilterChip
                  ]}
                  onPress={() => setSelectedCategory(item)}
                >
                  <Text style={[
                    styles.filterChipText,
                    selectedCategory === item && styles.activeFilterChipText
                  ]}>
                    {item}
                  </Text>
                </TouchableOpacity>
              )}
              keyExtractor={(item) => item}
            />
          </View>

          {/* Author Filter */}
          <View style={styles.filterSection}>
            <Text style={styles.filterLabel}>Author</Text>
            <FlatList
              data={authors.slice(0, 10)} // Show first 10 authors
              horizontal
              showsHorizontalScrollIndicator={false}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.filterChip,
                    selectedAuthor === item && styles.activeFilterChip
                  ]}
                  onPress={() => setSelectedAuthor(item)}
                >
                  <Text style={[
                    styles.filterChipText,
                    selectedAuthor === item && styles.activeFilterChipText
                  ]} numberOfLines={1}>
                    {item}
                  </Text>
                </TouchableOpacity>
              )}
              keyExtractor={(item) => item}
            />
          </View>

          {/* Sort Options */}
          <View style={styles.filterSection}>
            <Text style={styles.filterLabel}>Sort By</Text>
            <View style={styles.sortOptions}>
              {[
                { key: 'latest', label: 'Latest' },
                { key: 'oldest', label: 'Oldest' },
                { key: 'title', label: 'Title A-Z' },
                { key: 'author', label: 'Author A-Z' },
              ].map((option) => (
                <TouchableOpacity
                  key={option.key}
                  style={[
                    styles.sortOption,
                    sortBy === option.key && styles.activeSortOption
                  ]}
                  onPress={() => setSortBy(option.key)}
                >
                  <Text style={[
                    styles.sortOptionText,
                    sortBy === option.key && styles.activeSortOptionText
                  ]}>
                    {option.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Actions */}
          <View style={styles.modalActions}>
            <Button
              title="Reset"
              type="outline"
              buttonStyle={styles.resetBtn}
              titleStyle={styles.resetBtnText}
              onPress={resetFilters}
            />
            <Button
              title="Apply"
              buttonStyle={styles.applyBtn}
              onPress={() => setShowFilters(false)}
            />
          </View>
        </View>
      </View>
    </Modal>
  );

  const getPaginatedData = () => {
    const endIndex = page * ITEMS_PER_PAGE;
    return filteredBooks.slice(0, endIndex);
  };

  return (
    <View style={styles.container}>
      <CustomHeader
        centerComponent={{
          text: 'Explore Books'
        }}
        rightComponent={{
          icon: 'filter-variant',
          color: '#fff',
          onPress: () => setShowFilters(true)
        }}
        backgroundColor="#007bff"
      />

      {/* Search Bar */}
      <SearchBar
        placeholder="Search books or authors..."
        onChangeText={setSearchQuery}
        value={searchQuery}
        containerStyle={styles.searchContainer}
        inputContainerStyle={styles.searchInputContainer}
        inputStyle={styles.searchInput}
        round
      />

      {/* Active Filters */}
      {(selectedCategory !== 'All' || selectedAuthor !== 'All' || sortBy !== 'latest') && (
        <View style={styles.activeFilters}>
          <Text style={styles.activeFiltersText}>Active filters:</Text>
          {selectedCategory !== 'All' && (
            <View style={styles.activeFilterChip}>
              <Text style={styles.activeFilterText}>{selectedCategory}</Text>
            </View>
          )}
          {selectedAuthor !== 'All' && (
            <View style={styles.activeFilterChip}>
              <Text style={styles.activeFilterText}>{selectedAuthor}</Text>
            </View>
          )}
          {sortBy !== 'latest' && (
            <View style={styles.activeFilterChip}>
              <Text style={styles.activeFilterText}>
                {sortBy === 'title' ? 'Title A-Z' : 
                 sortBy === 'author' ? 'Author A-Z' : 
                 sortBy === 'oldest' ? 'Oldest' : 'Latest'}
              </Text>
            </View>
          )}
        </View>
      )}

      <FlatList
        data={getPaginatedData()}
        renderItem={renderBookItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        onEndReached={loadMore}
        onEndReachedThreshold={0.1}
        ListHeaderComponent={
          randomPicks.length > 0 ? (
            <View style={styles.randomSection}>
              <Text style={styles.sectionTitle}>🎲 Random Picks</Text>
              <FlatList
                data={randomPicks}
                renderItem={renderRandomPick}
                keyExtractor={(item) => `random-${item.id}`}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.randomList}
              />
            </View>
          ) : null
        }
        ListEmptyComponent={
          !loading ? (
            <View style={styles.emptyContainer}>
              <MaterialCommunityIcons name="book-search" size={64} color="#CCC" />
              <Text style={styles.emptyTitle}>No Books Found</Text>
              <Text style={styles.emptySubtitle}>
                Try adjusting your search or filters
              </Text>
              <Button
                title="Reset Filters"
                buttonStyle={styles.resetFiltersBtn}
                onPress={resetFilters}
              />
            </View>
          ) : null
        }
        ListFooterComponent={
          hasMore && getPaginatedData().length > 0 ? (
            <View style={styles.loadMoreContainer}>
              <Button
                title="Load More"
                type="outline"
                buttonStyle={styles.loadMoreBtn}
                onPress={loadMore}
              />
            </View>
          ) : null
        }
      />

      {renderFilterModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    backgroundColor: 'transparent',
    borderBottomColor: 'transparent',
    borderTopColor: 'transparent',
    paddingHorizontal: 15,
    paddingVertical: 10,
  },
  searchInputContainer: {
    backgroundColor: '#F8F9FA',
    borderRadius: 25,
  },
  searchInput: {
    fontSize: 16,
  },
  activeFilters: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingBottom: 10,
    flexWrap: 'wrap',
  },
  activeFiltersText: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY,
    marginRight: 8,
  },
  activeFilterChip: {
    backgroundColor: '#007AFF',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 6,
    marginBottom: 4,
  },
  activeFilterText: {
    fontSize: 11,
    color: '#FFF',
    fontWeight: '500',
  },
  randomSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginBottom: 15,
    paddingHorizontal: 15,
  },
  randomList: {
    paddingLeft: 15,
  },
  randomPickItem: {
    width: 120,
    marginRight: 15,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
    shadowColor: COLORS.SHADOW,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  randomPickCover: {
    width: '100%',
    height: 160,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
  },
  randomPickInfo: {
    padding: 8,
  },
  randomPickTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.TEXT,
  },
  randomPickAuthor: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 2,
  },
  listContainer: {
    padding: 15,
  },
  bookItem: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
    shadowColor: COLORS.SHADOW,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  bookCover: {
    width: 70,
    height: 105,
    borderRadius: 8,
  },
  bookInfo: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'space-between',
  },
  bookTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginBottom: 4,
  },
  bookAuthor: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 4,
  },
  bookCategory: {
    fontSize: 12,
    color: '#007AFF',
    marginBottom: 4,
  },
  bookPages: {
    fontSize: 11,
    color: '#999',
    marginBottom: 8,
  },
  bookActions: {
    flexDirection: 'row',
  },
  actionBtn: {
    borderRadius: 15,
    paddingVertical: 6,
    paddingHorizontal: 12,
    marginRight: 8,
  },
  readBtn: {
    backgroundColor: '#007AFF',
  },
  listenBtn: {
    backgroundColor: '#FFD700',
  },
  actionBtnText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  favoriteBtn: {
    padding: 5,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingTop: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    textAlign: 'center',
    marginBottom: 24,
  },
  resetFiltersBtn: {
    backgroundColor: '#007AFF',
    borderRadius: 25,
  },
  loadMoreContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  loadMoreBtn: {
    borderColor: '#007AFF',
    borderRadius: 25,
    paddingHorizontal: 24,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT,
  },
  filterSection: {
    marginBottom: 20,
  },
  filterLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.TEXT,
    marginBottom: 10,
  },
  filterChip: {
    backgroundColor: '#F8F9FA',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  activeFilterChip: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
  filterChipText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
  },
  activeFilterChipText: {
    color: '#FFF',
    fontWeight: '500',
  },
  sortOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  sortOption: {
    backgroundColor: '#F8F9FA',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginRight: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  activeSortOption: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
  sortOptionText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
  },
  activeSortOptionText: {
    color: '#FFF',
    fontWeight: '500',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  resetBtn: {
    borderColor: '#DC3545',
    borderRadius: 25,
    flex: 0.45,
  },
  resetBtnText: {
    color: '#DC3545',
  },
  applyBtn: {
    backgroundColor: '#007AFF',
    borderRadius: 25,
    flex: 0.45,
  },
});

export default ExploreScreen;
