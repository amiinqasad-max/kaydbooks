import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Text,
} from 'react-native';
import { Avatar, List } from 'react-native-paper';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { getUserProfile } from '../services/supabase';
import { COLORS, FONTS, SPACING, BORDER_RADIUS, COMMON_STYLES } from '../constants/theme';
import LanguageSelector from '../components/LanguageSelector';

const SimpleProfileScreen = ({ navigation }) => {
  const { t } = useTranslation();
  const { user, signOut } = useAuth();
  const { currentLanguage, getLanguageName } = useLanguage();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);

  useEffect(() => {
    if (user) {
      loadProfile();
    }
  }, [user]);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const profileData = await getUserProfile(user.id);
      setProfile(profileData);
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadProfile();
    setRefreshing(false);
  };

  const getUserName = () => {
    if (profile?.name) return profile.name;
    if (user?.user_metadata?.name) return user.user_metadata.name;
    if (user?.email) return user.email.split('@')[0];
    return 'User';
  };

  const getUserEmail = () => {
    return profile?.email || user?.email || 'No email';
  };

  const handleSignOut = () => {
    Alert.alert(
      t('profile.signOut'),
      t('profile.signOutConfirm'),
      [
        { text: t('common.cancel'), style: 'cancel' },
        { 
          text: t('profile.signOut'), 
          style: 'destructive',
          onPress: async () => {
            try {
              await signOut();
            } catch (error) {
              console.error('Error signing out:', error);
              Alert.alert(t('common.error'), 'Failed to sign out. Please try again.');
            }
          }
        }
      ]
    );
  };

  // Memoize profile options to ensure they update when language changes
  const profileOptions = React.useMemo(() => [
    // Removed edit-profile option
    {
      id: 'downloads',
      title: t('profile.myDownloads'),
      subtitle: t('profile.accessDownloads'),
      icon: 'download',
      onPress: () => navigation.navigate('Downloads'),
    },
    {
      id: 'language',
      title: t('profile.language'),
      subtitle: getLanguageName(currentLanguage),
      icon: 'translate',
      onPress: () => setShowLanguageSelector(true),
    },
    // Removed pricing option
    // Removed about option
    {
      id: 'sign-out',
      title: t('profile.signOut'),
      subtitle: t('profile.signOutConfirm'),
      icon: 'logout',
      onPress: handleSignOut,
      isDestructive: true,
    },
  ], [t, currentLanguage, getLanguageName]);

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={[COLORS.BUTTON, 'rgba(250, 181, 0, 0.8)']}
        style={styles.headerGradient}
      >
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>👤 {t('navigation.profile')}</Text>
        </View>
      </LinearGradient>

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[COLORS.BUTTON]}
            tintColor={COLORS.BUTTON}
          />
        }
      >
        {/* User Info Card */}
        <View style={styles.userCard}>
          <LinearGradient
            colors={['rgba(250, 181, 0, 0.1)', 'rgba(2, 25, 69, 0.95)']}
            style={styles.userCardGradient}
          >
            {/* Avatar */}
            <View style={styles.avatarContainer}>
              <Avatar.Text
                size={80}
                label={getUserName().charAt(0).toUpperCase()}
                style={styles.avatar}
                labelStyle={styles.avatarText}
              />
            </View>

            {/* User Details */}
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{getUserName()}</Text>
              <Text style={styles.userEmail}>{getUserEmail()}</Text>
              
              {/* Removed edit profile button */}
            </View>
          </LinearGradient>
        </View>

        {/* Profile Options */}
        <View style={styles.optionsSection}>
          <Text style={styles.sectionTitle}>{t('settings.title')}</Text>
          
          {profileOptions.map((option) => (
            <TouchableOpacity
              key={option.id}
              style={[
                styles.optionCard,
                option.isDestructive && styles.destructiveOption
              ]}
              onPress={option.onPress}
              activeOpacity={0.7}
            >
              <LinearGradient
                colors={
                  option.isDestructive 
                    ? ['rgba(244, 67, 54, 0.1)', 'rgba(2, 25, 69, 0.95)']
                    : ['rgba(250, 181, 0, 0.05)', 'rgba(2, 25, 69, 0.95)']
                }
                style={styles.optionGradient}
              >
                <View style={styles.optionContent}>
                  <View style={[
                    styles.optionIcon,
                    option.isDestructive && styles.destructiveIcon
                  ]}>
                    <MaterialCommunityIcons 
                      name={option.icon} 
                      size={24} 
                      color={option.isDestructive ? COLORS.ERROR : COLORS.BUTTON} 
                    />
                  </View>
                  
                  <View style={styles.optionText}>
                    <Text style={[
                      styles.optionTitle,
                      option.isDestructive && styles.destructiveText
                    ]}>
                      {option.title}
                    </Text>
                    <Text style={styles.optionSubtitle}>
                      {option.subtitle}
                    </Text>
                  </View>
                  
                  <MaterialCommunityIcons 
                    name="chevron-right" 
                    size={20} 
                    color={COLORS.BORDER} 
                  />
                </View>
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>

        {/* App Version */}
        <View style={styles.versionSection}>
          <Text style={styles.versionText}>{t('profile.appVersion')}</Text>
          <Text style={styles.versionSubtext}>{t('profile.madeWithLove')}</Text>
        </View>

        {/* Language Selector Modal */}
        <LanguageSelector
          visible={showLanguageSelector}
          onClose={() => setShowLanguageSelector(false)}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BACKGROUND,
  },
  headerGradient: {
    paddingTop: 50,
    paddingBottom: SPACING.LG,
  },
  headerContent: {
    alignItems: 'center',
    paddingHorizontal: SPACING.LG,
  },
  headerTitle: {
    fontSize: FONTS.SIZES.TITLE,
    fontWeight: 'bold',
    color: COLORS.BUTTON_TEXT,
  },
  scrollView: {
    flex: 1,
  },
  userCard: {
    margin: SPACING.LG,
    borderRadius: BORDER_RADIUS.LG,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: COLORS.BUTTON,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  userCardGradient: {
    padding: SPACING.LG,
    alignItems: 'center',
  },
  avatarContainer: {
    marginBottom: SPACING.LG,
  },
  avatar: {
    backgroundColor: COLORS.BUTTON,
    borderWidth: 3,
    borderColor: 'rgba(250, 181, 0, 0.3)',
  },
  avatarText: {
    color: COLORS.BUTTON_TEXT,
    fontSize: FONTS.SIZES.TITLE,
    fontWeight: 'bold',
  },
  userInfo: {
    alignItems: 'center',
    width: '100%',
  },
  userName: {
    fontSize: FONTS.SIZES.XLARGE,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginBottom: SPACING.XS,
  },
  userEmail: {
    fontSize: FONTS.SIZES.MEDIUM,
    color: COLORS.TEXT,
    opacity: 0.7,
    marginBottom: SPACING.LG,
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.BUTTON,
    borderRadius: BORDER_RADIUS.MD,
    paddingHorizontal: SPACING.LG,
    paddingVertical: SPACING.SM,
  },
  editButtonText: {
    color: COLORS.BUTTON_TEXT,
    fontSize: FONTS.SIZES.MEDIUM,
    fontWeight: 'bold',
    marginLeft: SPACING.XS,
  },
  optionsSection: {
    paddingHorizontal: SPACING.LG,
    marginBottom: SPACING.XL,
  },
  sectionTitle: {
    fontSize: FONTS.SIZES.LARGE,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginBottom: SPACING.LG,
  },
  optionCard: {
    marginBottom: SPACING.MD,
    borderRadius: BORDER_RADIUS.LG,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: COLORS.BUTTON,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  destructiveOption: {
    // Additional styling for destructive options if needed
  },
  optionGradient: {
    padding: SPACING.LG,
  },
  optionContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  optionIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(250, 181, 0, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SPACING.MD,
  },
  destructiveIcon: {
    backgroundColor: 'rgba(244, 67, 54, 0.2)',
  },
  optionText: {
    flex: 1,
  },
  optionTitle: {
    fontSize: FONTS.SIZES.MEDIUM,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginBottom: SPACING.XS,
  },
  destructiveText: {
    color: COLORS.ERROR,
  },
  optionSubtitle: {
    fontSize: FONTS.SIZES.SMALL,
    color: COLORS.TEXT,
    opacity: 0.7,
  },
  versionSection: {
    alignItems: 'center',
    paddingVertical: SPACING.XL,
    paddingHorizontal: SPACING.LG,
  },
  versionText: {
    fontSize: FONTS.SIZES.SMALL,
    color: COLORS.TEXT,
    opacity: 0.6,
    marginBottom: SPACING.XS,
  },
  versionSubtext: {
    fontSize: FONTS.SIZES.SMALL,
    color: COLORS.TEXT,
    opacity: 0.5,
  },
});

export default SimpleProfileScreen;
