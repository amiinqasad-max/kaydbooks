import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
} from 'react-native';
import { Text } from 'react-native';
import { Button, Appbar } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';
import {
  getTopReads,
  addToFavorites,
  removeFromFavorites,
  isFavorite,
} from '../services/supabase';

const TopReadsScreen = ({ navigation }) => {
  const { user } = useAuth();
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [favorites, setFavorites] = useState({});

  useEffect(() => {
    loadBooks();
  }, []);

  const loadBooks = async () => {
    try {
      setLoading(true);
      const booksData = await getTopReads(50); // Load more books
      setBooks(booksData);

      // Load favorites status
      if (user) {
        const favoritesStatus = {};
        await Promise.all(
          booksData.map(async (book) => {
            const isFav = await isFavorite(user.id, book.id);
            favoritesStatus[book.id] = isFav;
          })
        );
        setFavorites(favoritesStatus);
      }
    } catch (error) {
      console.error('Error loading top reads:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadBooks();
    setRefreshing(false);
  };

  const toggleFavorite = async (bookId) => {
    if (!user) {
      navigation.navigate('Login');
      return;
    }

    try {
      const currentlyFavorite = favorites[bookId];
      
      if (currentlyFavorite) {
        await removeFromFavorites(user.id, bookId);
      } else {
        await addToFavorites(user.id, bookId);
      }
      
      setFavorites(prev => ({
        ...prev,
        [bookId]: !currentlyFavorite
      }));
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const renderBookItem = ({ item }) => (
    <TouchableOpacity
      style={styles.bookItem}
      onPress={() => navigation.navigate('BookDetail', { book: item })}
    >
      <Image source={{ uri: item.cover_url }} style={styles.bookCover} />
      <View style={styles.bookInfo}>
        <Text style={styles.bookTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.bookAuthor} numberOfLines={1}>
          by {item.author}
        </Text>
        <Text style={styles.bookCategory}>{item.category}</Text>
        {item.pages && (
          <Text style={styles.bookPages}>{item.pages} pages</Text>
        )}
        <View style={styles.bookActions}>
          <Button
            title="Read Now"
            buttonStyle={styles.readBtn}
            titleStyle={styles.actionBtnText}
            onPress={() => navigation.navigate('PDFViewer', { book: item })}
          />
        </View>
      </View>
      <TouchableOpacity
        style={styles.favoriteBtn}
        onPress={() => toggleFavorite(item.id)}
      >
        <MaterialCommunityIcons
          name={favorites[item.id] ? "heart" : "heart-outline"}
          size={24}
          color={favorites[item.id] ? "#FF6B6B" : "#CCC"}
        />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Appbar.Header style={{ backgroundColor: '#007AFF' }}>
        <Appbar.BackAction onPress={() => navigation.goBack()} />
        <Appbar.Content title="Top Reads" titleStyle={{ color: '#fff', fontSize: 18, fontWeight: 'bold' }} />
      </Appbar.Header>

      <FlatList
        data={books}
        renderItem={renderBookItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          !loading ? (
            <View style={styles.emptyContainer}>
              <MaterialCommunityIcons name="book-outline" size={64} color="#CCC" />
              <Text style={styles.emptyTitle}>No Books Available</Text>
              <Text style={styles.emptySubtitle}>
                Check back later for new additions
              </Text>
            </View>
          ) : null
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  listContainer: {
    padding: 15,
  },
  bookItem: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
    shadowColor: COLORS.SHADOW,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  bookCover: {
    width: 70,
    height: 105,
    borderRadius: 8,
  },
  bookInfo: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'space-between',
  },
  bookTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginBottom: 4,
  },
  bookAuthor: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 4,
  },
  bookCategory: {
    fontSize: 12,
    color: '#007AFF',
    marginBottom: 4,
  },
  bookPages: {
    fontSize: 11,
    color: '#999',
    marginBottom: 8,
  },
  bookActions: {
    flexDirection: 'row',
  },
  readBtn: {
    backgroundColor: '#007AFF',
    borderRadius: 15,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  actionBtnText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  favoriteBtn: {
    padding: 5,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingTop: 100,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    textAlign: 'center',
  },
});

export default TopReadsScreen;
