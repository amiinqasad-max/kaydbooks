import React from 'react';
import { View, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import { Appbar } from 'react-native-paper';
import { COLORS, COMMON_STYLES } from '../constants/theme';

const PDFViewScreen = ({ route, navigation }) => {
  const { pdfUrl } = route.params;
  
  // Use Google Docs viewer to prevent downloads
  const googleDocsUrl = `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(pdfUrl)}`;

  return (
    <View style={styles.container}>
      <Appbar.Header style={styles.header}>
        <Appbar.BackAction onPress={() => navigation.goBack()} />
        <Appbar.Content title="PDF Reader" titleStyle={styles.headerTitle} />
      </Appbar.Header>
      
      <WebView
        source={{ uri: googleDocsUrl }}
        style={styles.webview}
        startInLoadingState={true}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        allowsInlineMediaPlayback={true}
        mediaPlaybackRequiresUserAction={false}
        mixedContentMode="compatibility"
        onShouldStartLoadWithRequest={(request) => {
          // Allow Google Docs viewer and the PDF URL
          return request.url.includes('docs.google.com') || request.url === pdfUrl;
        }}
        onError={(error) => {
          console.error('PDF WebView Error:', error);
        }}
        userAgent="Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BACKGROUND,
  },
  header: {
    backgroundColor: COLORS.BACKGROUND,
    elevation: 0,
    shadowOpacity: 0,
  },
  headerTitle: {
    color: COLORS.TEXT,
    fontSize: 18,
    fontWeight: 'bold',
  },
  webview: {
    flex: 1,
    backgroundColor: COLORS.BACKGROUND,
  },
});

export default PDFViewScreen;
