import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  RefreshControl,
  Alert,
  TouchableOpacity,
  Image,
} from 'react-native';
import { Text } from 'react-native';
import { Button, Searchbar, Appbar } from 'react-native-paper';
import { useAuth } from '../contexts/AuthContext';
import { getBooks, signOut } from '../services/supabase';
import CustomHeader from '../components/CustomHeader';

const HomeScreen = ({ navigation }) => {
  const { user } = useAuth();
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');

  const loadBooks = async () => {
    try {
      const booksData = await getBooks();
      setBooks(booksData);
      setFilteredBooks(booksData);
    } catch (error) {
      Alert.alert('Error', 'Failed to load books: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBooks();
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadBooks();
    setRefreshing(false);
  }, []);

  const handleSearch = (text) => {
    setSearch(text);
    if (text === '') {
      setFilteredBooks(books);
    } else {
      const filtered = books.filter(
        (book) =>
          book.title.toLowerCase().includes(text.toLowerCase()) ||
          book.author.toLowerCase().includes(text.toLowerCase())
      );
      setFilteredBooks(filtered);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error) {
      Alert.alert('Error', 'Failed to logout: ' + error.message);
    }
  };

  const renderBook = ({ item }) => (
    <TouchableOpacity
      onPress={() => navigation.navigate('BookDetail', { book: item })}
    >
      <Card containerStyle={styles.bookCard}>
        <View style={styles.bookContent}>
          <Image
            source={{ uri: item.cover_url }}
            style={styles.bookCover}
            resizeMode="cover"
          />
          <View style={styles.bookInfo}>
            <Text style={styles.bookTitle} numberOfLines={2}>
              {item.title}
            </Text>
            <Text style={styles.bookAuthor} numberOfLines={1}>
              by {item.author}
            </Text>
            <View style={styles.bookActions}>
              <Button
                title="Read"
                buttonStyle={[
                  styles.actionButton, 
                  styles.readButton,
                  !item.audio_url && styles.singleButton
                ]}
                titleStyle={styles.actionButtonText}
                onPress={() => navigation.navigate('PDFViewer', { book: item })}
              />
              {item.audio_url && (
                <Button
                  title="Listen"
                  buttonStyle={[styles.actionButton, styles.listenButton]}
                  titleStyle={styles.actionButtonText}
                  onPress={() => navigation.navigate('AudioPlayer', { book: item })}
                />
              )}
            </View>
          </View>
        </View>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <CustomHeader
        centerComponent={{
          text: 'Book Library'
        }}
        rightComponent={{
          icon: 'logout',
          color: '#fff',
          onPress: handleLogout
        }}
        backgroundColor="#007bff"
      />

      <SearchBar
        placeholder="Search books or authors..."
        onChangeText={handleSearch}
        value={search}
        containerStyle={styles.searchContainer}
        inputContainerStyle={styles.searchInputContainer}
      />

      {user?.email === 'admin@bookapp.com' && (
        <View style={styles.adminButtonsContainer}>
          <Button
            title="Upload Book"
            buttonStyle={[styles.adminButton, styles.uploadButton]}
            onPress={() => navigation.navigate('AdminUpload')}
          />
          <Button
            title="Manage Books"
            buttonStyle={[styles.adminButton, styles.manageButton]}
            onPress={() => navigation.navigate('AdminManage')}
          />
        </View>
      )}

      <FlatList
        data={filteredBooks}
        renderItem={renderBook}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              {loading ? 'Loading books...' : 'No books available'}
            </Text>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  searchContainer: {
    backgroundColor: 'transparent',
    borderBottomColor: 'transparent',
    borderTopColor: 'transparent',
    paddingHorizontal: 10,
  },
  searchInputContainer: {
    backgroundColor: '#fff',
  },
  adminButtonsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  adminButton: {
    flex: 1,
    marginHorizontal: 5,
    borderRadius: 5,
  },
  uploadButton: {
    backgroundColor: '#28a745',
  },
  manageButton: {
    backgroundColor: '#dc3545',
  },
  listContainer: {
    padding: 10,
  },
  bookCard: {
    borderRadius: 10,
    marginBottom: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  bookContent: {
    flexDirection: 'row',
  },
  bookCover: {
    width: 80,
    height: 120,
    borderRadius: 5,
  },
  bookInfo: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'space-between',
  },
  bookTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  bookAuthor: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },
  bookActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 8,
    flex: 0.45,
  },
  singleButton: {
    flex: 1,
  },
  readButton: {
    backgroundColor: '#007bff',
  },
  listenButton: {
    backgroundColor: '#17a2b8',
  },
  actionButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 50,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});

export default HomeScreen;
