import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
  Alert,
} from 'react-native';
import { Text } from 'react-native';
import { Button, Appbar } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system';
import { useAuth } from '../contexts/AuthContext';
import {
  getFavorites,
  getContinueReadingBooks,
  getUserDownloads,
  getUserProgressWithBooks,
  supabase,
} from '../services/supabase';
import { COLORS, FONTS, SPACING, BORDER_RADIUS, COMMON_STYLES } from '../constants/theme';

const LibraryScreen = ({ navigation }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('favorites');
  const [favorites, setFavorites] = useState([]);
  const [downloads, setDownloads] = useState([]);
  const [continueReading, setContinueReading] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (user) {
      loadLibraryData();
    }
  }, [user, activeTab]);

  const loadLibraryData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Load favorites with book details
      const favoritesData = await getFavorites(user.id);
      setFavorites(favoritesData || []);

      // Load continue reading books with progress
      const continueReadingData = await getContinueReadingBooks(user.id);
      setContinueReading(continueReadingData || []);

      // Load downloads with book details
      const downloadsData = await getUserDownloads(user.id);
      setDownloads(downloadsData || []);

    } catch (error) {
      console.error('Error loading library data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadDownloads = async () => {
    try {
      // Check for downloaded files in the app's document directory
      const downloadDir = `${FileSystem.documentDirectory}downloads/`;
      const dirInfo = await FileSystem.getInfoAsync(downloadDir);
      
      if (dirInfo.exists) {
        const files = await FileSystem.readDirectoryAsync(downloadDir);
        const downloadedBooks = [];
        
        for (const file of files) {
          if (file.endsWith('.json')) {
            const bookInfoPath = `${downloadDir}${file}`;
            const bookInfoContent = await FileSystem.readAsStringAsync(bookInfoPath);
            const bookInfo = JSON.parse(bookInfoContent);
            downloadedBooks.push(bookInfo);
          }
        }
        
        setDownloads(downloadedBooks);
      } else {
        setDownloads([]);
      }
    } catch (error) {
      console.error('Error loading downloads:', error);
      setDownloads([]);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const removeFavorite = async (bookId) => {
    try {
      await removeFromFavorites(user.id, bookId);
      setFavorites(prev => prev.filter(item => item.book_id !== bookId));
    } catch (error) {
      console.error('Error removing favorite:', error);
      Alert.alert('Error', 'Failed to remove from favorites');
    }
  };

  const deleteDownload = async (book) => {
    Alert.alert(
      'Delete Download',
      `Remove "${book.title}" from downloads?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const downloadDir = `${FileSystem.documentDirectory}downloads/`;
              const bookInfoPath = `${downloadDir}${book.id}.json`;
              const pdfPath = `${downloadDir}${book.id}.pdf`;
              const audioPath = `${downloadDir}${book.id}.mp3`;

              // Delete files if they exist
              await Promise.all([
                FileSystem.deleteAsync(bookInfoPath, { idempotent: true }),
                FileSystem.deleteAsync(pdfPath, { idempotent: true }),
                FileSystem.deleteAsync(audioPath, { idempotent: true }),
              ]);

              await loadDownloads();
            } catch (error) {
              console.error('Error deleting download:', error);
              Alert.alert('Error', 'Failed to delete download');
            }
          }
        }
      ]
    );
  };

  const renderFavoriteItem = ({ item }) => {
    const book = item.books;
    
    return (
      <TouchableOpacity
        style={styles.libraryItem}
        onPress={() => navigation.navigate('BookDetail', { book })}
      >
        <Image source={{ uri: book.cover_url }} style={styles.bookCover} />
        <View style={styles.bookInfo}>
          <Text style={styles.bookTitle} numberOfLines={2}>
            {book.title}
          </Text>
          <Text style={styles.bookAuthor} numberOfLines={1}>
            by {book.author}
          </Text>
          <Text style={styles.bookCategory}>{book.category}</Text>
          <View style={styles.bookActions}>
            <Button
              title="Read"
              buttonStyle={[styles.actionBtn, styles.readBtn]}
              titleStyle={styles.actionBtnText}
              onPress={() => navigation.navigate('PDFViewer', { book })}
            />
            {book.audio_url && (
              <Button
                title="Listen"
                buttonStyle={[styles.actionBtn, styles.listenBtn]}
                titleStyle={styles.actionBtnText}
                onPress={() => navigation.navigate('AudioPlayer', { book })}
              />
            )}
          </View>
        </View>
        <TouchableOpacity
          style={styles.removeBtn}
          onPress={() => removeFavorite(item.book_id)}
        >
          <MaterialCommunityIcons name="heart" size={24} color="#FF6B6B" />
        </TouchableOpacity>
      </TouchableOpacity>
    );
  };

  const renderDownloadItem = ({ item }) => (
    <TouchableOpacity
      style={styles.libraryItem}
      onPress={() => navigation.navigate('BookDetail', { book: item })}
    >
      <Image source={{ uri: item.cover_url }} style={styles.bookCover} />
      <View style={styles.bookInfo}>
        <Text style={styles.bookTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.bookAuthor} numberOfLines={1}>
          by {item.author}
        </Text>
        <View style={styles.downloadInfo}>
          <MaterialCommunityIcons name="download" size={16} color="#28A745" />
          <Text style={styles.downloadText}>Downloaded</Text>
        </View>
        <View style={styles.bookActions}>
          <Button
            title="Read Offline"
            buttonStyle={[styles.actionBtn, styles.readBtn]}
            titleStyle={styles.actionBtnText}
            onPress={() => {
              // Navigate to offline PDF viewer
              navigation.navigate('PDFViewer', { 
                book: { ...item, isOffline: true }
              });
            }}
          />
          {item.hasAudio && (
            <Button
              title="Listen Offline"
              buttonStyle={[styles.actionBtn, styles.listenBtn]}
              titleStyle={styles.actionBtnText}
              onPress={() => {
                navigation.navigate('AudioPlayer', { 
                  book: { ...item, isOffline: true }
                });
              }}
            />
          )}
        </View>
      </View>
      <TouchableOpacity
        style={styles.removeBtn}
        onPress={() => deleteDownload(item)}
      >
        <MaterialCommunityIcons name="delete" size={24} color="#DC3545" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const renderContinueItem = ({ item }) => {
    const book = item.books;
    const progress = item.progress_percentage || 0;
    
    return (
      <TouchableOpacity
        style={styles.libraryItem}
        onPress={() => navigation.navigate('PDFViewer', { 
          book, 
          startPage: item.last_page 
        })}
      >
        <Image source={{ uri: book.cover_url }} style={styles.bookCover} />
        <View style={styles.bookInfo}>
          <Text style={styles.bookTitle} numberOfLines={2}>
            {book.title}
          </Text>
          <Text style={styles.bookAuthor} numberOfLines={1}>
            by {book.author}
          </Text>
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View 
                style={[styles.progressFill, { width: `${progress}%` }]} 
              />
            </View>
            <Text style={styles.progressText}>{Math.round(progress)}%</Text>
          </View>
          <Text style={styles.lastReadText}>
            Page {item.last_page} of {item.total_pages || '?'}
          </Text>
          <View style={styles.bookActions}>
            <Button
              title="Continue Reading"
              buttonStyle={[styles.actionBtn, styles.continueBtn]}
              titleStyle={styles.actionBtnText}
              onPress={() => navigation.navigate('PDFViewer', { 
                book, 
                startPage: item.last_page 
              })}
            />
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderEmptyState = () => {
    const emptyMessages = {
      favorites: {
        icon: 'heart-outline',
        title: 'No Favorites Yet',
        subtitle: 'Books you favorite will appear here'
      },
      downloads: {
        icon: 'download-outline',
        title: 'No Downloads',
        subtitle: 'Download books for offline reading'
      },
      continue: {
        icon: 'book-open-outline',
        title: 'No Reading Progress',
        subtitle: 'Start reading to track your progress'
      }
    };

    const message = emptyMessages[activeTab];

    return (
      <View style={styles.emptyContainer}>
        <MaterialCommunityIcons 
          name={message.icon} 
          size={64} 
          color="#CCC" 
        />
        <Text style={styles.emptyTitle}>{message.title}</Text>
        <Text style={styles.emptySubtitle}>{message.subtitle}</Text>
        <Button
          title="Explore Books"
          buttonStyle={styles.exploreBtn}
          onPress={() => navigation.navigate('Explore')}
        />
      </View>
    );
  };

  const getCurrentData = () => {
    switch (activeTab) {
      case 'favorites':
        return favorites;
      case 'downloads':
        return downloads;
      case 'continue':
        return continueReading;
      default:
        return [];
    }
  };

  const getCurrentRenderItem = () => {
    switch (activeTab) {
      case 'favorites':
        return renderFavoriteItem;
      case 'downloads':
        return renderDownloadItem;
      case 'continue':
        return renderContinueItem;
      default:
        return renderFavoriteItem;
    }
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <Appbar.Header style={{ backgroundColor: COLORS.BACKGROUND }}>
          <Appbar.Content title="My Library" titleStyle={COMMON_STYLES.headerTitle} />
        </Appbar.Header>
        <View style={styles.loginPrompt}>
          <MaterialCommunityIcons name="account-outline" size={64} color={COLORS.BORDER} />
          <Text style={styles.loginTitle}>Sign In Required</Text>
          <Text style={styles.loginSubtitle}>
            Please sign in to access your library
          </Text>
          <Button
            mode="contained"
            style={styles.signInBtn}
            onPress={() => navigation.navigate('Login')}
          >
            Sign In
          </Button>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Appbar.Header style={{ backgroundColor: COLORS.BACKGROUND }}>
        <Appbar.Content title="My Library" titleStyle={COMMON_STYLES.headerTitle} />
      </Appbar.Header>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'favorites' && styles.activeTab]}
          onPress={() => setActiveTab('favorites')}
        >
          <MaterialCommunityIcons 
            name="heart" 
            size={20} 
            color={activeTab === 'favorites' ? COLORS.BUTTON : COLORS.TEXT_SECONDARY} 
          />
          <Text style={[
            styles.tabText, 
            activeTab === 'favorites' && styles.activeTabText
          ]}>
            Favorites
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'downloads' && styles.activeTab]}
          onPress={() => setActiveTab('downloads')}
        >
          <MaterialCommunityIcons 
            name="download" 
            size={20} 
            color={activeTab === 'downloads' ? COLORS.BUTTON : COLORS.TEXT_SECONDARY} 
          />
          <Text style={[
            styles.tabText, 
            activeTab === 'downloads' && styles.activeTabText
          ]}>
            Downloads
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'continue' && styles.activeTab]}
          onPress={() => setActiveTab('continue')}
        >
          <MaterialCommunityIcons 
            name="book-open" 
            size={20} 
            color={activeTab === 'continue' ? COLORS.BUTTON : COLORS.TEXT_SECONDARY} 
          />
          <Text style={[
            styles.tabText, 
            activeTab === 'continue' && styles.activeTabText
          ]}>
            Continue
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <FlatList
        data={getCurrentData()}
        renderItem={getCurrentRenderItem()}
        keyExtractor={(item, index) => `${activeTab}-${item.id || index}`}
        contentContainerStyle={styles.listContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={renderEmptyState}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#F8F9FA',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: COLORS.BUTTON,
  },
  tabText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginLeft: 5,
    fontWeight: '500',
  },
  activeTabText: {
    color: COLORS.BUTTON,
    fontWeight: 'bold',
  },
  listContainer: {
    padding: 15,
  },
  libraryItem: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  bookCover: {
    width: 60,
    height: 90,
    borderRadius: 8,
  },
  bookInfo: {
    flex: 1,
    marginLeft: 15,
    justifyContent: 'space-between',
  },
  bookTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginBottom: 4,
  },
  bookAuthor: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 4,
  },
  bookCategory: {
    fontSize: 12,
    color: COLORS.BUTTON,
    marginBottom: 8,
  },
  downloadInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  downloadText: {
    fontSize: 12,
    color: '#28A745',
    marginLeft: 4,
    fontWeight: '500',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: '#E0E0E0',
    borderRadius: 3,
    marginRight: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: COLORS.BUTTON,
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '500',
  },
  lastReadText: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 8,
  },
  bookActions: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  actionBtn: {
    borderRadius: 15,
    paddingVertical: 6,
    paddingHorizontal: 12,
    marginRight: 8,
  },
  readBtn: {
    backgroundColor: COLORS.BUTTON,
  },
  listenBtn: {
    backgroundColor: '#FFD700',
  },
  continueBtn: {
    backgroundColor: '#28A745',
  },
  actionBtnText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  removeBtn: {
    padding: 5,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    textAlign: 'center',
    marginBottom: 24,
  },
  exploreBtn: {
    backgroundColor: COLORS.BUTTON,
    borderRadius: 25,
    paddingHorizontal: 24,
  },
  loginPrompt: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loginTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.TEXT,
    marginTop: 16,
    marginBottom: 8,
  },
  loginSubtitle: {
    fontSize: 16,
    color: COLORS.TEXT_SECONDARY,
    textAlign: 'center',
    marginBottom: 32,
  },
  signInBtn: {
    backgroundColor: COLORS.BUTTON,
    borderRadius: 25,
    paddingHorizontal: 32,
  },
});

export default LibraryScreen;
