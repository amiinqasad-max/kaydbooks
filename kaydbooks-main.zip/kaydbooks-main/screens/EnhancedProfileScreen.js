import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { Text } from 'react-native';
import { Avatar, Card, List } from 'react-native-paper';
import { ProgressBar } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';
import {
  getFavorites,
  getReadingStats,
  getTodayReadingTime,
  getReadingGoals,
} from '../services/supabase';
import { COLORS, FONTS, SPACING, BORDER_RADIUS, COMMON_STYLES } from '../constants/theme';
import CustomHeader from '../components/CustomHeader';

const EnhancedProfileScreen = ({ navigation }) => {
  const { user, signOut } = useAuth();
  const [userStats, setUserStats] = useState({
    booksRead: 0,
    hoursRead: 0,
    favoriteBooks: 0,
    pagesRead: 0,
    todayMinutes: 0,
  });
  const [readingGoals, setReadingGoals] = useState({
    daily_minutes: 30,
    monthly_books: 2,
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadUserStats();
    }
  }, [user]);

  const loadUserStats = async () => {
    try {
      setLoading(true);
      
      // Get comprehensive reading stats
      const stats = await getReadingStats(user.id);
      
      // Get today's reading time
      const todayMinutes = await getTodayReadingTime(user.id);
      
      // Get reading goals
      const goals = await getReadingGoals(user.id);
      
      // Get favorites count
      const favorites = await getFavorites(user.id);

      setUserStats({
        booksRead: stats.booksRead,
        hoursRead: stats.hoursRead,
        favoriteBooks: favorites?.length || 0,
        pagesRead: stats.pagesRead,
        todayMinutes,
      });

      if (goals) {
        setReadingGoals(goals);
      }

    } catch (error) {
      console.error('Error loading user stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDailyProgress = () => {
    return Math.min((userStats.todayMinutes / readingGoals.daily_minutes) * 100, 100);
  };

  const getMonthlyProgress = () => {
    // This is simplified - in a real app you'd calculate books read this month
    return Math.min((userStats.booksRead / readingGoals.monthly_books) * 100, 100);
  };

  const formatTime = (minutes) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  const getUserInitials = () => {
    const name = user?.user_metadata?.name || user?.email?.split('@')[0] || 'User';
    return name.charAt(0).toUpperCase();
  };

  const getUserName = () => {
    return user?.user_metadata?.name || user?.email?.split('@')[0] || 'User';
  };

  const handleLogout = () => {
    signOut();
  };

  return (
    <View style={styles.container}>
      <CustomHeader
        centerComponent={{
          text: 'Profile'
        }}
        rightComponent={{
          icon: 'cog',
          color: COLORS.TEXT,
          onPress: () => navigation.navigate('Settings')
        }}
        backgroundColor={COLORS.BACKGROUND}
        borderBottomColor={COLORS.BORDER}
      />

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* User Info */}
        <View style={styles.userSection}>
          <Avatar
            size={80}
            rounded
            title={getUserInitials()}
            containerStyle={styles.avatar}
            titleStyle={styles.avatarText}
          />
          <Text style={styles.userName}>{getUserName()}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
          <Text style={styles.memberSince}>
            Member since {new Date(user?.created_at).toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'long' 
            })}
          </Text>
        </View>

        {/* Reading Goals Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🎯 Today's Goals</Text>
          
          <Card containerStyle={styles.goalCard}>
            <View style={styles.goalItem}>
              <View style={styles.goalHeader}>
                <MaterialCommunityIcons name="clock-outline" size={20} color={COLORS.BUTTON} />
                <Text style={styles.goalTitle}>Daily Reading</Text>
              </View>
              <Text style={styles.goalText}>
                {formatTime(userStats.todayMinutes)} / {formatTime(readingGoals.daily_minutes)}
              </Text>
              <ProgressBar
                progress={getDailyProgress() / 100}
                color={COLORS.BUTTON}
                style={styles.progressBar}
              />
              <Text style={styles.goalPercentage}>
                {Math.round(getDailyProgress())}% complete
              </Text>
            </View>
          </Card>

          <TouchableOpacity onPress={() => navigation.navigate('ReadingGoals')}>
            <Card containerStyle={styles.goalCard}>
              <View style={styles.goalItem}>
                <View style={styles.goalHeader}>
                  <MaterialCommunityIcons name="book-multiple" size={20} color={COLORS.BUTTON} />
                  <Text style={styles.goalTitle}>Monthly Books</Text>
                  <MaterialCommunityIcons name="chevron-right" size={20} color={COLORS.TEXT} />
                </View>
                <Text style={styles.goalText}>
                  {userStats.booksRead} / {readingGoals.monthly_books} books
                </Text>
                <ProgressBar
                  progress={getMonthlyProgress() / 100}
                  color={COLORS.BUTTON}
                  style={styles.progressBar}
                />
                <Text style={styles.goalPercentage}>
                  {Math.round(getMonthlyProgress())}% complete
                </Text>
              </View>
            </Card>
          </TouchableOpacity>
        </View>

        {/* Reading Statistics */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>📊 My Stats</Text>
            <TouchableOpacity onPress={() => navigation.navigate('ReadingStats')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.statsGrid}>
            <Card containerStyle={styles.statCard}>
              <View style={styles.statContent}>
                <MaterialCommunityIcons name="book-multiple" size={24} color={COLORS.BUTTON} />
                <Text style={styles.statNumber}>{userStats.booksRead}</Text>
                <Text style={styles.statLabel}>Books Read</Text>
              </View>
            </Card>

            <Card containerStyle={styles.statCard}>
              <View style={styles.statContent}>
                <MaterialCommunityIcons name="clock" size={24} color={COLORS.BUTTON} />
                <Text style={styles.statNumber}>{userStats.hoursRead}h</Text>
                <Text style={styles.statLabel}>Hours Read</Text>
              </View>
            </Card>

            <Card containerStyle={styles.statCard}>
              <View style={styles.statContent}>
                <MaterialCommunityIcons name="heart" size={24} color={COLORS.BUTTON} />
                <Text style={styles.statNumber}>{userStats.favoriteBooks}</Text>
                <Text style={styles.statLabel}>Favorites</Text>
              </View>
            </Card>

            <Card containerStyle={styles.statCard}>
              <View style={styles.statContent}>
                <MaterialCommunityIcons name="file-document" size={24} color={COLORS.BUTTON} />
                <Text style={styles.statNumber}>{userStats.pagesRead}</Text>
                <Text style={styles.statLabel}>Pages Read</Text>
              </View>
            </Card>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>⚡ Quick Actions</Text>
          
          <TouchableOpacity onPress={() => navigation.navigate('ReadingGoals')}>
            <ListItem containerStyle={styles.actionItem}>
              <MaterialCommunityIcons name="target" size={24} color={COLORS.BUTTON} />
              <ListItem.Content>
                <ListItem.Title style={styles.actionTitle}>Reading Goals</ListItem.Title>
                <ListItem.Subtitle style={styles.actionSubtitle}>Set and track your goals</ListItem.Subtitle>
              </ListItem.Content>
              <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.TEXT} />
            </ListItem>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('ReadingStats')}>
            <ListItem containerStyle={styles.actionItem}>
              <MaterialCommunityIcons name="chart-line" size={24} color={COLORS.BUTTON} />
              <ListItem.Content>
                <ListItem.Title style={styles.actionTitle}>Reading Statistics</ListItem.Title>
                <ListItem.Subtitle style={styles.actionSubtitle}>View detailed analytics</ListItem.Subtitle>
              </ListItem.Content>
              <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.TEXT} />
            </ListItem>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Settings')}>
            <ListItem containerStyle={styles.actionItem}>
              <MaterialCommunityIcons name="cog" size={24} color={COLORS.BUTTON} />
              <ListItem.Content>
                <ListItem.Title style={styles.actionTitle}>Settings</ListItem.Title>
                <ListItem.Subtitle style={styles.actionSubtitle}>Manage your preferences</ListItem.Subtitle>
              </ListItem.Content>
              <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.TEXT} />
            </ListItem>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('EditProfile')}>
            <ListItem containerStyle={styles.actionItem}>
              <MaterialCommunityIcons name="account-edit" size={24} color={COLORS.BUTTON} />
              <ListItem.Content>
                <ListItem.Title style={styles.actionTitle}>Edit Profile</ListItem.Title>
                <ListItem.Subtitle style={styles.actionSubtitle}>Update your information</ListItem.Subtitle>
              </ListItem.Content>
              <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.TEXT} />
            </ListItem>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('About')}>
            <ListItem containerStyle={styles.actionItem}>
              <MaterialCommunityIcons name="information" size={24} color={COLORS.BUTTON} />
              <ListItem.Content>
                <ListItem.Title style={styles.actionTitle}>About</ListItem.Title>
                <ListItem.Subtitle style={styles.actionSubtitle}>App information</ListItem.Subtitle>
              </ListItem.Content>
              <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.TEXT} />
            </ListItem>
          </TouchableOpacity>
        </View>

        {/* Logout Button */}
        <View style={styles.logoutSection}>
          <Button
            title="Sign Out"
            buttonStyle={styles.logoutButton}
            titleStyle={styles.logoutButtonText}
            onPress={handleLogout}
            icon={
              <MaterialCommunityIcons 
                name="logout" 
                size={20} 
                color={COLORS.ERROR} 
                style={{ marginRight: 8 }} 
              />
            }
          />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: COMMON_STYLES.container,
  scrollView: {
    flex: 1,
  },
  userSection: {
    alignItems: 'center',
    paddingVertical: SPACING.XL,
    backgroundColor: COLORS.BACKGROUND,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER,
  },
  avatar: {
    backgroundColor: COLORS.BUTTON,
    marginBottom: SPACING.MD,
  },
  avatarText: {
    fontSize: FONTS.SIZES.HEADER,
    fontWeight: 'bold',
    color: COLORS.BUTTON_TEXT,
  },
  userName: {
    ...COMMON_STYLES.title,
    fontSize: FONTS.SIZES.TITLE,
    marginBottom: SPACING.XS,
  },
  userEmail: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.MEDIUM,
    opacity: 0.8,
    marginBottom: SPACING.XS,
  },
  memberSince: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.SMALL,
    opacity: 0.6,
  },
  section: {
    marginBottom: SPACING.LG,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: SPACING.LG,
    marginBottom: SPACING.MD,
    marginTop: SPACING.MD,
  },
  sectionTitle: {
    fontSize: FONTS.SIZES.XLARGE,
    fontWeight: 'bold',
    color: COLORS.BUTTON,
  },
  seeAllText: {
    color: COLORS.BUTTON,
    fontSize: FONTS.SIZES.MEDIUM,
    fontWeight: '600',
  },
  goalCard: {
    backgroundColor: COLORS.BACKGROUND,
    borderRadius: BORDER_RADIUS.LG,
    marginHorizontal: SPACING.LG,
    marginBottom: SPACING.MD,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
  },
  goalItem: {
    padding: SPACING.SM,
  },
  goalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: SPACING.SM,
  },
  goalTitle: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.LARGE,
    fontWeight: '600',
    flex: 1,
    marginLeft: SPACING.SM,
  },
  goalText: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.XLARGE,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: SPACING.SM,
  },
  progressBar: {
    height: 6,
    borderRadius: 3,
    backgroundColor: COLORS.PROGRESS_BACKGROUND,
    marginBottom: SPACING.SM,
  },
  goalPercentage: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.SMALL,
    textAlign: 'center',
    opacity: 0.8,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.LG,
  },
  statCard: {
    backgroundColor: COLORS.BACKGROUND,
    borderRadius: BORDER_RADIUS.LG,
    width: '48%',
    marginBottom: SPACING.MD,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
  },
  statContent: {
    alignItems: 'center',
    padding: SPACING.SM,
  },
  statNumber: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.XXLARGE,
    fontWeight: 'bold',
    marginTop: SPACING.SM,
    marginBottom: SPACING.XS,
  },
  statLabel: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.SMALL,
    opacity: 0.8,
    textAlign: 'center',
  },
  actionItem: {
    backgroundColor: COLORS.BACKGROUND,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER,
    paddingVertical: SPACING.MD,
  },
  actionTitle: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.LARGE,
    fontWeight: '600',
  },
  actionSubtitle: {
    ...COMMON_STYLES.text,
    fontSize: FONTS.SIZES.MEDIUM,
    opacity: 0.7,
    marginTop: 2,
  },
  logoutSection: {
    padding: SPACING.LG,
    paddingTop: SPACING.XL,
  },
  logoutButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: COLORS.ERROR,
    borderRadius: BORDER_RADIUS.LG,
    paddingVertical: SPACING.MD,
  },
  logoutButtonText: {
    color: COLORS.ERROR,
    fontSize: FONTS.SIZES.LARGE,
    fontWeight: '600',
  },
});

export default EnhancedProfileScreen;
