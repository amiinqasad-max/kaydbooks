import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Image,
  Alert,
  Text,
} from 'react-native';
import {
  Button,
  Card,
} from 'react-native-paper';
import Slider from '@react-native-community/slider';
import { Audio } from 'expo-av';
import CustomHeader from '../components/CustomHeader';

const AudioPlayerScreen = ({ navigation, route }) => {
  const { book } = route.params;
  const [sound, setSound] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    return sound
      ? () => {
          sound.unloadAsync();
        }
      : undefined;
  }, [sound]);

  const loadAudio = async () => {
    try {
      setIsLoading(true);
      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: book.audio_url },
        { shouldPlay: false },
        onPlaybackStatusUpdate
      );
      setSound(newSound);
    } catch (error) {
      Alert.alert('Error', 'Failed to load audio file: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const onPlaybackStatusUpdate = (status) => {
    if (status.isLoaded) {
      setPosition(status.positionMillis || 0);
      setDuration(status.durationMillis || 0);
      setIsPlaying(status.isPlaying);
    }
  };

  const playPauseAudio = async () => {
    try {
      if (!sound) {
        await loadAudio();
        return;
      }

      if (isPlaying) {
        await sound.pauseAsync();
      } else {
        await sound.playAsync();
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to play/pause audio: ' + error.message);
    }
  };

  const stopAudio = async () => {
    try {
      if (sound) {
        await sound.stopAsync();
        await sound.setPositionAsync(0);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to stop audio: ' + error.message);
    }
  };

  const seekAudio = async (value) => {
    try {
      if (sound && duration > 0) {
        const seekPosition = (value / 100) * duration;
        await sound.setPositionAsync(seekPosition);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to seek audio: ' + error.message);
    }
  };

  const formatTime = (milliseconds) => {
    const totalSeconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const progressPercentage = duration > 0 ? (position / duration) * 100 : 0;

  return (
    <View style={styles.container}>
      <CustomHeader
        leftComponent={{
          icon: 'arrow-left',
          color: '#fff',
          onPress: () => navigation.goBack()
        }}
        centerComponent={{
          text: 'Audio Player'
        }}
        backgroundColor="#17a2b8"
      />

      <View style={styles.content}>
        <Card containerStyle={styles.playerCard}>
          <View style={styles.bookInfo}>
            <Image
              source={{ uri: book.cover_url }}
              style={styles.bookCover}
              resizeMode="cover"
            />
            <Text style={styles.bookTitle}>{book.title}</Text>
            <Text style={styles.bookAuthor}>by {book.author}</Text>
          </View>

          <View style={styles.progressContainer}>
            <Text style={styles.timeText}>{formatTime(position)}</Text>
            <Slider
              style={styles.progressSlider}
              value={progressPercentage}
              onSlidingComplete={seekAudio}
              thumbStyle={styles.sliderThumb}
              trackStyle={styles.sliderTrack}
              minimumTrackTintColor="#17a2b8"
              maximumTrackTintColor="#ddd"
            />
            <Text style={styles.timeText}>{formatTime(duration)}</Text>
          </View>

          <View style={styles.controls}>
            <Button
              title="⏹️"
              onPress={stopAudio}
              buttonStyle={[styles.controlButton, styles.stopButton]}
              titleStyle={styles.controlButtonText}
              disabled={!sound}
            />
            
            <Button
              title={isLoading ? "⏳" : isPlaying ? "⏸️" : "▶️"}
              onPress={playPauseAudio}
              buttonStyle={[styles.controlButton, styles.playButton]}
              titleStyle={styles.playButtonText}
              loading={isLoading}
            />
            
            <Button
              title="🔄"
              onPress={loadAudio}
              buttonStyle={[styles.controlButton, styles.reloadButton]}
              titleStyle={styles.controlButtonText}
            />
          </View>
        </Card>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  playerCard: {
    borderRadius: 20,
    padding: 30,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  bookInfo: {
    alignItems: 'center',
    marginBottom: 40,
  },
  bookCover: {
    width: 200,
    height: 300,
    borderRadius: 15,
    marginBottom: 20,
  },
  bookTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  bookAuthor: {
    fontSize: 18,
    color: '#666',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
  },
  timeText: {
    fontSize: 14,
    color: '#666',
    minWidth: 50,
    textAlign: 'center',
  },
  progressSlider: {
    flex: 1,
    marginHorizontal: 10,
  },
  sliderThumb: {
    backgroundColor: '#17a2b8',
    width: 20,
    height: 20,
  },
  sliderTrack: {
    height: 4,
    borderRadius: 2,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlButton: {
    borderRadius: 50,
    width: 60,
    height: 60,
    marginHorizontal: 10,
  },
  playButton: {
    backgroundColor: '#17a2b8',
    width: 80,
    height: 80,
  },
  stopButton: {
    backgroundColor: '#dc3545',
  },
  reloadButton: {
    backgroundColor: '#6c757d',
  },
  controlButtonText: {
    fontSize: 20,
  },
  playButtonText: {
    fontSize: 24,
  },
});

export default AudioPlayerScreen;
