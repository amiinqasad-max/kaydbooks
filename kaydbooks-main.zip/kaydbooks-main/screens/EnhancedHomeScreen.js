import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Image,
  Dimensions,
  RefreshControl,
} from 'react-native';
import { Text } from 'react-native';
import { Searchbar, Card, Button } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import debounce from 'lodash.debounce';
import { useAuth } from '../contexts/AuthContext';
import {
  searchBooks,
  getTopReads,
  getTopAudiobooks,
  getCategories,
  addToFavorites,
  removeFromFavorites,
  isFavorite,
} from '../services/supabase';

const { width } = Dimensions.get('window');
const BOOK_CARD_WIDTH = width * 0.35;

const EnhancedHomeScreen = ({ navigation }) => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [topReads, setTopReads] = useState([]);
  const [topAudiobooks, setTopAudiobooks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [favorites, setFavorites] = useState({});

  // Category icons mapping
  const categoryIcons = {
    'Islamic': 'mosque',
    'Motivation': 'lightbulb-on',
    'Technology': 'laptop',
    'History': 'book-open-page-variant',
    'Science': 'flask',
    'Fiction': 'book-open',
    'Business': 'briefcase',
    'Health': 'heart-pulse',
    'Education': 'school',
    'Philosophy': 'head-lightbulb',
    'Biography': 'account',
    'Self-Help': 'human-handsup',
  };

  const loadInitialData = async () => {
    try {
      setLoading(true);
      const [readsData, audiobooksData, categoriesData] = await Promise.all([
        getTopReads(8),
        getTopAudiobooks(8),
        getCategories(),
      ]);

      setTopReads(readsData);
      setTopAudiobooks(audiobooksData);
      setCategories(categoriesData.slice(0, 8)); // Show max 8 categories

      // Load favorites status for displayed books
      if (user) {
        const allBooks = [...readsData, ...audiobooksData];
        const favoritesStatus = {};
        
        await Promise.all(
          allBooks.map(async (book) => {
            const isFav = await isFavorite(user.id, book.id);
            favoritesStatus[book.id] = isFav;
          })
        );
        
        setFavorites(favoritesStatus);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, [user]);

  const debouncedSearch = useCallback(
    debounce(async (query) => {
      if (query.trim()) {
        try {
          const results = await searchBooks(query, 10);
          setSearchResults(results);
        } catch (error) {
          console.error('Search error:', error);
          setSearchResults([]);
        }
      } else {
        setSearchResults([]);
      }
    }, 300),
    []
  );

  const handleSearch = (text) => {
    setSearchQuery(text);
    debouncedSearch(text);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadInitialData();
    setRefreshing(false);
  };

  const toggleFavorite = async (bookId) => {
    if (!user) return;

    try {
      const currentlyFavorite = favorites[bookId];
      
      if (currentlyFavorite) {
        await removeFromFavorites(user.id, bookId);
      } else {
        await addToFavorites(user.id, bookId);
      }
      
      setFavorites(prev => ({
        ...prev,
        [bookId]: !currentlyFavorite
      }));
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const renderBookCard = ({ item, showPlayIcon = false }) => (
    <TouchableOpacity
      style={styles.bookCard}
      onPress={() => navigation.navigate('BookDetail', { book: item })}
    >
      <View style={styles.bookImageContainer}>
        <Image source={{ uri: item.cover_url }} style={styles.bookImage} />
        {showPlayIcon && (
          <View style={styles.playIconOverlay}>
            <MaterialCommunityIcons name="play-circle" size={24} color="#007AFF" />
          </View>
        )}
        {user && (
          <TouchableOpacity
            style={styles.favoriteButton}
            onPress={() => toggleFavorite(item.id)}
          >
            <MaterialCommunityIcons
              name={favorites[item.id] ? "heart" : "heart-outline"}
              size={20}
              color={favorites[item.id] ? "#FF6B6B" : "#FFF"}
            />
          </TouchableOpacity>
        )}
      </View>
      <View style={styles.bookInfo}>
        <Text style={styles.bookTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.bookAuthor} numberOfLines={1}>
          {item.author}
        </Text>
        <View style={styles.bookActions}>
          <Button
            title="Read"
            buttonStyle={[styles.actionBtn, styles.readBtn]}
            titleStyle={styles.actionBtnText}
            onPress={() => navigation.navigate('PDFViewer', { book: item })}
          />
          {item.audio_url && (
            <Button
              title="Listen"
              buttonStyle={[styles.actionBtn, styles.listenBtn]}
              titleStyle={styles.actionBtnText}
              onPress={() => navigation.navigate('AudioPlayer', { book: item })}
            />
          )}
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderCategoryCard = (category, index) => (
    <TouchableOpacity
      key={index}
      style={styles.categoryCard}
      onPress={() => navigation.navigate('CategoryBooks', { category })}
    >
      <MaterialCommunityIcons
        name={categoryIcons[category] || 'book'}
        size={32}
        color="#007AFF"
      />
      <Text style={styles.categoryName}>{category}</Text>
    </TouchableOpacity>
  );

  const renderSearchResult = ({ item }) => (
    <TouchableOpacity
      style={styles.searchResultItem}
      onPress={() => {
        navigation.navigate('BookDetail', { book: item });
        setSearchQuery('');
        setSearchResults([]);
      }}
    >
      <Image source={{ uri: item.cover_url }} style={styles.searchResultImage} />
      <View style={styles.searchResultInfo}>
        <Text style={styles.searchResultTitle}>{item.title}</Text>
        <Text style={styles.searchResultAuthor}>{item.author}</Text>
        <Text style={styles.searchResultCategory}>{item.category}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <SearchBar
        placeholder="Search books or authors..."
        onChangeText={handleSearch}
        value={searchQuery}
        containerStyle={styles.searchContainer}
        inputContainerStyle={styles.searchInputContainer}
        inputStyle={styles.searchInput}
        searchIcon={{ size: 20, color: '#666' }}
        clearIcon={{ size: 20, color: '#666' }}
        round
      />

      {/* Search Results */}
      {searchResults.length > 0 && (
        <View style={styles.searchResultsContainer}>
          <FlatList
            data={searchResults}
            renderItem={renderSearchResult}
            keyExtractor={(item) => item.id.toString()}
            style={styles.searchResultsList}
            keyboardShouldPersistTaps="handled"
          />
        </View>
      )}

      {/* Main Content */}
      {searchResults.length === 0 && (
        <ScrollView
          style={styles.scrollView}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
        >
          {/* Welcome Section */}
          <View style={styles.welcomeSection}>
            <Text style={styles.welcomeText}>
              Welcome back{user ? `, ${user.email?.split('@')[0]}` : ''}! 📚
            </Text>
            <Text style={styles.welcomeSubtext}>
              Discover your next great read
            </Text>
          </View>

          {/* Top Reads Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>📚 Top Reads</Text>
              <Button
                title="See All"
                type="clear"
                titleStyle={styles.seeAllText}
                onPress={() => navigation.navigate('TopReads')}
              />
            </View>
            <FlatList
              data={topReads}
              renderItem={({ item }) => renderBookCard({ item })}
              keyExtractor={(item) => item.id.toString()}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalList}
            />
          </View>

          {/* Top Audiobooks Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>🎧 Top Audiobooks</Text>
              <Button
                title="See All"
                type="clear"
                titleStyle={styles.seeAllText}
                onPress={() => navigation.navigate('TopAudiobooks')}
              />
            </View>
            <FlatList
              data={topAudiobooks}
              renderItem={({ item }) => renderBookCard({ item, showPlayIcon: true })}
              keyExtractor={(item) => item.id.toString()}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalList}
            />
          </View>

          {/* Categories Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>🗂️ Categories</Text>
            <View style={styles.categoriesGrid}>
              {categories.map((category, index) => renderCategoryCard(category, index))}
            </View>
          </View>

          {/* Admin Section */}
          {user?.email === 'admin@bookapp.com' && (
            <View style={styles.adminSection}>
              <Text style={styles.sectionTitle}>⚙️ Admin Panel</Text>
              <View style={styles.adminButtons}>
                <Button
                  title="Upload Book"
                  buttonStyle={[styles.adminBtn, styles.uploadBtn]}
                  onPress={() => navigation.navigate('AdminUpload')}
                />
                <Button
                  title="Manage Books"
                  buttonStyle={[styles.adminBtn, styles.manageBtn]}
                  onPress={() => navigation.navigate('AdminManage')}
                />
              </View>
            </View>
          )}

        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  searchContainer: {
    backgroundColor: 'transparent',
    borderBottomColor: 'transparent',
    borderTopColor: 'transparent',
    paddingHorizontal: 15,
    paddingTop: 10,
  },
  searchInputContainer: {
    backgroundColor: '#F8F9FA',
    borderRadius: 25,
    height: 45,
  },
  searchInput: {
    fontSize: 16,
    color: '#333',
  },
  searchResultsContainer: {
    backgroundColor: '#FFF',
    maxHeight: 300,
    marginHorizontal: 15,
    borderRadius: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  searchResultsList: {
    padding: 10,
  },
  searchResultItem: {
    flexDirection: 'row',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  searchResultImage: {
    width: 40,
    height: 60,
    borderRadius: 5,
  },
  searchResultInfo: {
    flex: 1,
    marginLeft: 10,
    justifyContent: 'center',
  },
  searchResultTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  searchResultAuthor: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  searchResultCategory: {
    fontSize: 11,
    color: '#007AFF',
    marginTop: 2,
  },
  scrollView: {
    flex: 1,
  },
  welcomeSection: {
    padding: 20,
    backgroundColor: '#F8F9FA',
    marginBottom: 10,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  welcomeSubtext: {
    fontSize: 16,
    color: '#666',
  },
  section: {
    marginBottom: 25,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  seeAllText: {
    color: '#007AFF',
    fontSize: 14,
    fontWeight: '600',
  },
  horizontalList: {
    paddingLeft: 20,
  },
  bookCard: {
    width: BOOK_CARD_WIDTH,
    marginRight: 15,
    backgroundColor: '#FFF',
    borderRadius: 12,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  bookImageContainer: {
    position: 'relative',
  },
  bookImage: {
    width: '100%',
    height: 180,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  playIconOverlay: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 15,
    padding: 5,
  },
  favoriteButton: {
    position: 'absolute',
    top: 10,
    left: 10,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 15,
    padding: 5,
  },
  bookInfo: {
    padding: 12,
  },
  bookTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  bookAuthor: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
  },
  bookActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionBtn: {
    borderRadius: 15,
    paddingVertical: 6,
    paddingHorizontal: 12,
    flex: 0.48,
  },
  readBtn: {
    backgroundColor: '#007AFF',
  },
  listenBtn: {
    backgroundColor: '#FFD700',
  },
  actionBtnText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    justifyContent: 'space-between',
  },
  categoryCard: {
    width: '48%',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginBottom: 15,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  categoryName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginTop: 8,
    textAlign: 'center',
  },
  categorySubtitle: {
    fontSize: 12,
    color: '#666',
    marginTop: 8,
    textAlign: 'center',
  },
  adminSection: {
    padding: 20,
    backgroundColor: '#F8F9FA',
    marginTop: 10,
  },
  adminButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  adminBtn: {
    flex: 1,
    marginHorizontal: 5,
    borderRadius: 8,
    paddingVertical: 12,
  },
  uploadBtn: {
    backgroundColor: '#28a745',
  },
  manageBtn: {
    backgroundColor: '#dc3545',
  },
});

export default EnhancedHomeScreen;
