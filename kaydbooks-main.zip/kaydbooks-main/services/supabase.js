import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import { sanitizeBookRecord, sanitizeBookArray, sanitizeNestedBookRecord } from '../utils/bookSanitizer';
import { detectMimeType, correctFileMimeType, validateFileForUpload } from '../utils/mimeDetector';
import AsyncStorage from '@react-native-async-storage/async-storage';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://diznvbjdfgiehtwegpvs.supabase.co';
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpem52YmpkZmdpZWh0d2VncHZzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwOTI4MTgsImV4cCI6MjA3NzY2ODgxOH0.vBCLMoEPyGICtNAjgfdioZo5vOV80G2_PRThjJfTY38';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Auth functions
export const signUp = async (email, password, name) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });

  if (error) throw error;

  if (data.user) {
    // Wait a moment for the auth session to be established
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Create profile with proper error handling
    const { error: profileError } = await supabase
      .from('profiles')
      .insert([
        {
          id: data.user.id,
          name: name || 'User',
          email: email,
          created_at: new Date().toISOString(),
        }
      ]);

    if (profileError) {
      // Profile creation failed, but user was created
      console.warn('Profile creation failed:', profileError.message);
    }
  }

  return data;
};

export const signIn = async (email, password) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

// Book reading functions (read-only) - WITH SANITIZATION
export const getBooks = async () => {
  try {
    console.log('Fetching books from database...');
    const { data, error } = await supabase
      .from('books')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Database error:', error);
      throw error;
    }
    
    console.log('Successfully fetched', data?.length || 0, 'books');
    
    // CRITICAL: Sanitize ALL books BEFORE returning to prevent level3 undefined errors
    const sanitizedBooks = sanitizeBookArray(data || []);
    console.log('Books sanitized with safe defaults');
    
    return sanitizedBooks;
  } catch (error) {
    console.error('Error in getBooks:', error);
    throw error;
  }
};

export const getBook = async (id) => {
  const { data, error } = await supabase
    .from('books')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw error;
  
  // CRITICAL: Sanitize single book BEFORE returning
  return sanitizeBookRecord(data);
};

// Reading progress functions
export const updateReadingProgress = async (userId, bookId, lastPage, totalPages) => {
  const progressPercentage = totalPages ? (lastPage / totalPages) * 100 : 0;
  
  const { data, error } = await supabase
    .from('reading_progress')
    .upsert([{
      user_id: userId,
      book_id: bookId,
      last_page: lastPage,
      total_pages: totalPages,
      progress_percentage: progressPercentage,
      updated_at: new Date().toISOString(),
    }]);

  if (error) throw error;
  return data;
};

export const getReadingProgress = async (userId, bookId) => {
  const { data, error } = await supabase
    .from('reading_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('book_id', bookId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

// Audio Download Functions
export const addDownloadRecord = async (userId, bookId, filePath, fileSize = null) => {
  try {
    const { data, error } = await supabase
      .from('downloads')
      .insert([{
        user_id: userId,
        book_id: bookId,
        file_path: filePath,
        file_size: fileSize,
        download_date: new Date().toISOString(),
      }]);

    if (error) throw error;
    return data;
  } catch (error) {
    throw error;
  }
};

export const getDownloadRecord = async (userId, bookId) => {
  const { data, error } = await supabase
    .from('downloads')
    .select('*')
    .eq('user_id', userId)
    .eq('book_id', bookId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

export const removeDownloadRecord = async (userId, bookId) => {
  const { error } = await supabase
    .from('downloads')
    .delete()
    .eq('user_id', userId)
    .eq('book_id', bookId);

  if (error) throw error;
};

export const getUserDownloads = async (userId) => {
  const { data, error } = await supabase
    .from('downloads')
    .select(`
      *,
      books (
        id,
        title,
        author,
        cover_url
      )
    `)
    .eq('user_id', userId)
    .order('download_date', { ascending: false });

  if (error) throw error;
  return data || [];
};

// User Profile Functions
export const getUserProfile = async (userId) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

export const updateUserProfile = async (userId, updates) => {
  const { data, error } = await supabase
    .from('profiles')
    .upsert([{
      id: userId,
      ...updates,
      updated_at: new Date().toISOString(),
    }]);

  if (error) throw error;
  return data;
};

// Audio Progress Functions
export const updateAudioProgress = async (userId, bookId, progressData) => {
  try {
    const { data, error } = await supabase
      .from('audio_progress')
      .upsert([{
        user_id: userId,
        book_id: bookId,
        current_time: progressData.currentTime || 0,
        duration: progressData.duration || 0,
        progress_percentage: progressData.progressPercentage || 0,
        playback_rate: progressData.playbackRate || 1.0,
        updated_at: new Date().toISOString(),
      }]);

    if (error) throw error;
    return data;
  } catch (error) {
    throw error;
  }
};

export const getAudioProgress = async (userId, bookId) => {
  try {
    const { data, error } = await supabase
      .from('audio_progress')
      .select('*')
      .eq('user_id', userId)
      .eq('book_id', bookId)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    return data;
  } catch (error) {
    throw error;
  }
};

// Reading Goals Functions
export const updateReadingGoals = async (userId, dailyMinutes, monthlyBooks) => {
  const { data, error } = await supabase
    .from('reading_goals')
    .upsert([{
      user_id: userId,
      daily_minutes: dailyMinutes,
      monthly_books: monthlyBooks,
      updated_at: new Date().toISOString(),
    }]);

  if (error) throw error;
  return data;
};

export const getReadingGoals = async (userId) => {
  const { data, error } = await supabase
    .from('reading_goals')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data;
};

// Continue Reading Books - Using audio_progress table since reading_progress doesn't exist
export const getContinueReadingBooks = async (userId) => {
  try {
    // Try to get from audio_progress table first
    const { data, error } = await supabase
      .from('audio_progress')
      .select(`
        *,
        books (
          id,
          title,
          author,
          cover_url,
          pdf_url,
          audio_url,
          category,
          description,
          created_at
        )
      `)
      .eq('user_id', userId)
      .gt('progress_percentage', 0)
      .lt('progress_percentage', 100)
      .order('updated_at', { ascending: false })
      .limit(5);

    if (error) {
      // If audio_progress doesn't work, return empty array
      return [];
    }
    
    // CRITICAL: Sanitize nested book records to prevent level3 undefined errors
    const sanitizedData = (data || []).map(sanitizeNestedBookRecord);
    console.log('Continue reading books sanitized');
    
    return sanitizedData;
  } catch (error) {
    // Return empty array if there's any error
    return [];
  }
};

// Favorites Functions
export const addToFavorites = async (userId, bookId) => {
  const { data, error } = await supabase
    .from('favorites')
    .insert([{
      user_id: userId,
      book_id: bookId,
      created_at: new Date().toISOString(),
    }]);

  if (error) throw error;
  return data;
};

export const removeFromFavorites = async (userId, bookId) => {
  const { error } = await supabase
    .from('favorites')
    .delete()
    .eq('user_id', userId)
    .eq('book_id', bookId);

  if (error) throw error;
};

export const isFavorite = async (userId, bookId) => {
  const { data, error } = await supabase
    .from('favorites')
    .select('id')
    .eq('user_id', userId)
    .eq('book_id', bookId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return !!data;
};

export const getFavoriteStatus = async (userId, bookId) => {
  const { data, error } = await supabase
    .from('favorites')
    .select('id')
    .eq('user_id', userId)
    .eq('book_id', bookId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return !!data;
};

export const getFavorites = async (userId) => {
  const { data, error } = await supabase
    .from('favorites')
    .select(`
      *,
      books (
        id,
        title,
        author,
        cover_url,
        category,
        description,
        pdf_url,
        audio_url,
        created_at
      )
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  
  // CRITICAL: Sanitize nested book records in favorites
  const sanitizedFavorites = (data || []).map(sanitizeNestedBookRecord);
  return sanitizedFavorites;
};

// Reading Progress Functions (Enhanced) - Using audio_progress table
export const updateReadingProgressDetailed = async (userId, bookId, currentPage, totalPages) => {
  try {
    const progressPercentage = totalPages ? Math.min((currentPage / totalPages) * 100, 100) : 0;
    
    // Try to update audio_progress table instead
    const { data, error } = await supabase
      .from('audio_progress')
      .upsert([{
        user_id: userId,
        book_id: bookId,
        progress_percentage: progressPercentage,
        updated_at: new Date().toISOString(),
      }]);

    if (error) {
      // If that fails, just return success without throwing
      return { success: true };
    }
    return data;
  } catch (error) {
    // Don't throw error, just return success
    return { success: true };
  }
};

export const getReadingProgressDetailed = async (userId, bookId) => {
  try {
    const { data, error } = await supabase
      .from('audio_progress')
      .select('*')
      .eq('user_id', userId)
      .eq('book_id', bookId)
      .single();

    if (error) {
      // Return default progress if not found
      return {
        progress_percentage: 0,
        current_page: 0,
        total_pages: 0,
        last_read: null
      };
    }
    
    return data || {
      progress_percentage: 0,
      current_page: 0,
      total_pages: 0,
      last_read: null
    };
  } catch (error) {
    // Return default progress on error
    return {
      progress_percentage: 0,
      current_page: 0,
      total_pages: 0,
      last_read: null
    };
  }
};

export const addReadingSession = async (userId, bookId, sessionData) => {
  try {
    // Try to add to reading_sessions, but don't fail if table doesn't exist
    const { data, error } = await supabase
      .from('reading_sessions')
      .insert([{
        user_id: userId,
        book_id: bookId,
        start_time: sessionData.startTime,
        end_time: sessionData.endTime,
        pages_read: sessionData.pagesRead || 0,
        session_duration: sessionData.duration || 0,
        created_at: new Date().toISOString(),
      }]);

    if (error) {
      // Return success even if table doesn't exist
      return { success: true };
    }
    return data;
  } catch (error) {
    // Return success even if there's an error
    return { success: true };
  }
};

// User Downloads Functions
export const addToUserDownloads = async (userId, bookId, downloadData) => {
  // Only allow audio downloads - restrict PDF downloads
  if (downloadData.download_type === 'pdf') {
    throw new Error('PDF downloads are not allowed. Only audio files can be downloaded.');
  }
  
  const { data, error } = await supabase
    .from('downloads')
    .insert([{
      user_id: userId,
      book_id: bookId,
      download_type: downloadData.download_type || 'audio',
      file_path: downloadData.file_path,
      file_size: downloadData.file_size || 0,
      download_date: new Date().toISOString()
    }]);

  if (error) throw error;
  return data;
};

export const removeFromUserDownloads = async (userId, bookId, downloadType) => {
  const { error } = await supabase
    .from('downloads')
    .delete()
    .eq('user_id', userId)
    .eq('book_id', bookId)
    .eq('download_type', downloadType);

  if (error) throw error;
};

export const checkIfDownloaded = async (userId, bookId) => {
  const record = await getDownloadRecord(userId, bookId);
  return !!record;
};

export const getUserProgressWithBooks = async (userId) => {
  try {
    // Try audio_progress table first
    const { data, error } = await supabase
      .from('audio_progress')
      .select(`
        *,
        books (
          id,
          title,
          author,
          cover_url,
          category
        )
      `)
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });

    if (error) {
      return [];
    }
    
    // CRITICAL: Sanitize nested book records in progress data
    const sanitizedProgress = (data || []).map(sanitizeNestedBookRecord);
    return sanitizedProgress;
  } catch (error) {
    return [];
  }
};

// Reading Stats Functions - Using available tables
export const getReadingStats = async (userId) => {
  try {
    // Try to get from audio_progress instead
    const { data: audioProgress, error: audioError } = await supabase
      .from('audio_progress')
      .select('book_id, progress_percentage')
      .eq('user_id', userId);

    const completedBooks = audioProgress?.filter(book => book.progress_percentage >= 100) || [];
    
    // Return basic stats
    return {
      booksCompleted: completedBooks.length,
      totalReadingTime: 0, // Default to 0 since reading_sessions may not exist
      booksInProgress: audioProgress?.filter(book => book.progress_percentage > 0 && book.progress_percentage < 100).length || 0,
    };
  } catch (error) {
    // Return default stats if there's any error
    return {
      booksCompleted: 0,
      totalReadingTime: 0,
      booksInProgress: 0,
    };
  }
};

export const getTodayReadingTime = async (userId) => {
  try {
    // Return 0 since reading_sessions table may not exist
    return 0;
  } catch (error) {
    return 0;
  }
};

// ========================================
// ADMIN FUNCTIONS - CLEAN & ERROR-FREE
// ========================================

// File Upload Function - WITH PROPER MIME TYPE DETECTION
export const uploadFile = async (file, bucket = 'books', folder = '') => {
  try {
    console.log('uploadFile called with:', { file: file?.name, bucket, folder });
    
    if (!file || !file.uri) {
      throw new Error('Invalid file provided');
    }

    // CRITICAL: Validate and correct MIME type BEFORE upload
    const validation = validateFileForUpload(file);
    if (!validation.success) {
      throw new Error(validation.error);
    }

    // Correct the file object with proper MIME type
    const correctedFile = correctFileMimeType(file);
    const properMimeType = detectMimeType(correctedFile);
    
    console.log(`MIME type corrected: ${file.type} → ${properMimeType}`);

    // Generate safe filename
    const timestamp = new Date().getTime();
    const randomId = Math.random().toString(36).substring(2, 15);
    const extension = correctedFile.name ? correctedFile.name.split('.').pop() : 'jpg';
    const safeFilename = `${folder ? folder + '/' : ''}${timestamp}_${randomId}.${extension}`;
    
    console.log('Generated filename:', safeFilename);

    // Read file as ArrayBuffer for React Native compatibility
    console.log('Fetching file from URI:', correctedFile.uri);
    const response = await fetch(correctedFile.uri);
    if (!response.ok) {
      throw new Error(`Failed to read file: ${response.statusText}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    if (!arrayBuffer || arrayBuffer.byteLength === 0) {
      throw new Error('File is empty or corrupted');
    }
    
    console.log('File size:', arrayBuffer.byteLength, 'bytes');

    // Upload to Supabase storage with CORRECT MIME TYPE
    console.log('Uploading to Supabase storage with MIME type:', properMimeType);
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(safeFilename, arrayBuffer, {
        cacheControl: '3600',
        upsert: true, // Allow overwriting files
        contentType: properMimeType, // Use detected MIME type, NOT generic "image"
      });

    if (error) {
      console.error('Supabase storage error:', error);
      
      // If bucket doesn't exist, try to create it
      if (error.message.includes('not found') || error.message.includes('does not exist')) {
        console.log('Bucket not found, attempting to create...');
        try {
          const { error: createError } = await supabase.storage.createBucket(bucket, {
            public: true,
            allowedMimeTypes: ['image/*', 'application/pdf', 'audio/*'],
            fileSizeLimit: 52428800, // 50MB
          });
          
          if (createError) {
            console.error('Failed to create bucket:', createError);
            throw new Error(`Bucket creation failed: ${createError.message}`);
          }
          
          console.log('Bucket created successfully, retrying upload...');
          
          // Retry upload after creating bucket with CORRECT MIME TYPE
          const { data: retryData, error: retryError } = await supabase.storage
            .from(bucket)
            .upload(safeFilename, arrayBuffer, {
              cacheControl: '3600',
              upsert: true,
              contentType: properMimeType, // Use detected MIME type in retry too
            });
            
          if (retryError) {
            throw new Error(`Retry upload failed: ${retryError.message}`);
          }
          
          return retryData.path;
        } catch (createError) {
          throw new Error(`Storage setup failed: ${createError.message}`);
        }
      }
      
      throw new Error(`Upload failed: ${error.message}`);
    }

    if (!data || !data.path) {
      throw new Error('Upload succeeded but no file path returned');
    }

    return data.path;
  } catch (error) {
    throw new Error(`File upload error: ${error.message}`);
  }
};

// Get Public URL for uploaded files
export const getPublicUrl = (bucket, path) => {
  try {
    if (!bucket || !path) {
      throw new Error('Bucket and path are required');
    }

    const { data } = supabase.storage
      .from(bucket)
      .getPublicUrl(path);

    if (!data || !data.publicUrl) {
      throw new Error('Failed to generate public URL');
    }

    return data.publicUrl;
  } catch (error) {
    throw new Error(`Public URL generation error: ${error.message}`);
  }
};

// Create Book Function - DEFENSIVE SCHEMA APPROACH
export const createBook = async (bookData) => {
  try {
    // CRITICAL: Only use core columns that are guaranteed to exist
    const coreBookData = {
      title: bookData.title?.trim() || '',
      author: bookData.author?.trim() || '',
      description: bookData.description?.trim() || '',
      category: bookData.category || 'General',
      cover_url: bookData.cover_url || null,
      pdf_url: bookData.pdf_url || null,
      audio_url: bookData.audio_url || null,
      created_at: new Date().toISOString(),
    };

    // OPTIONAL: Add columns only if they might exist (with error handling)
    const optionalFields = {
      isbn: bookData.isbn?.trim() || null,
      publication_year: bookData.publication_year ? parseInt(bookData.publication_year) : null,
      page_count: bookData.page_count ? parseInt(bookData.page_count) : null,
    };

    // Combine core and optional fields
    const cleanBookData = { ...coreBookData, ...optionalFields };

    // Validate required fields
    if (!cleanBookData.title || !cleanBookData.author) {
      throw new Error('Title and author are required');
    }

    console.log('Creating book with data:', cleanBookData);

    const { data, error } = await supabase
      .from('books')
      .insert([cleanBookData])
      .select();

    if (error) {
      throw new Error(`Failed to create book: ${error.message}`);
    }

    if (!data || data.length === 0) {
      throw new Error('Book creation failed - no data returned');
    }

    // CRITICAL: Sanitize created book before returning
    return sanitizeBookRecord(data[0]);
  } catch (error) {
    throw new Error(`Book creation error: ${error.message}`);
  }
};

// Update Book Function
export const updateBook = async (id, bookData) => {
  try {
    if (!id) {
      throw new Error('Book ID is required');
    }

    // Clean update data
    const updateData = {
      title: bookData.title?.trim() || undefined,
      author: bookData.author?.trim() || undefined,
      description: bookData.description?.trim() || undefined,
      category: bookData.category || undefined,
      cover_url: bookData.cover_url || undefined,
      pdf_url: bookData.pdf_url || undefined,
      audio_url: bookData.audio_url || undefined,
      isbn: bookData.isbn?.trim() || undefined,
      publication_year: bookData.publication_year ? parseInt(bookData.publication_year) : undefined,
      page_count: bookData.page_count ? parseInt(bookData.page_count) : undefined,
      is_premium: bookData.is_premium !== undefined ? Boolean(bookData.is_premium) : undefined,
      is_featured: bookData.is_featured !== undefined ? Boolean(bookData.is_featured) : undefined,
      updated_at: new Date().toISOString(),
    };

    // Remove undefined values
    Object.keys(updateData).forEach(key => {
      if (updateData[key] === undefined) {
        delete updateData[key];
      }
    });

    const { data, error } = await supabase
      .from('books')
      .update(updateData)
      .eq('id', id)
      .select();

    if (error) {
      throw new Error(`Failed to update book: ${error.message}`);
    }

    if (!data || data.length === 0) {
      throw new Error('Book not found or update failed');
    }

    // CRITICAL: Sanitize updated book before returning
    return sanitizeBookRecord(data[0]);
  } catch (error) {
    throw new Error(`Book update error: ${error.message}`);
  }
};

// Delete Book Function
export const deleteBook = async (id) => {
  try {
    if (!id) {
      throw new Error('Book ID is required');
    }

    const { error } = await supabase
      .from('books')
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`Failed to delete book: ${error.message}`);
    }

    return true;
  } catch (error) {
    throw new Error(`Book deletion error: ${error.message}`);
  }
};
