import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { transactionCode, userId, plan } = await req.json()

    if (!transactionCode || !userId || !plan) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Check if transaction code exists and is not already used
    const { data: existingPayment, error: checkError } = await supabaseClient
      .from('local_payments')
      .select('*')
      .eq('transaction_code', transactionCode)
      .eq('verified', false)
      .single()

    if (checkError || !existingPayment) {
      return new Response(
        JSON.stringify({ error: 'Invalid or already used transaction code' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Verify the payment amount matches the plan
    const expectedAmount = plan === 'monthly' ? 4.99 : 49.99
    if (existingPayment.amount !== expectedAmount || existingPayment.plan !== plan) {
      return new Response(
        JSON.stringify({ error: 'Payment amount or plan mismatch' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Calculate subscription end date
    let subscriptionEnd = new Date()
    
    switch (plan) {
      case 'monthly':
        subscriptionEnd.setMonth(subscriptionEnd.getMonth() + 1)
        break
      case 'yearly':
        subscriptionEnd.setFullYear(subscriptionEnd.getFullYear() + 1)
        break
    }

    // Update user subscription in database
    const { error: updateError } = await supabaseClient
      .from('users')
      .update({
        premium: true,
        subscription_plan: plan,
        subscription_start: new Date().toISOString(),
        subscription_end: subscriptionEnd.toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)

    if (updateError) {
      throw updateError
    }

    // Mark payment as verified
    const { error: verifyError } = await supabaseClient
      .from('local_payments')
      .update({
        verified: true,
        user_id: userId,
        verified_at: new Date().toISOString()
      })
      .eq('transaction_code', transactionCode)

    if (verifyError) {
      throw verifyError
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        subscriptionEnd: subscriptionEnd.toISOString(),
        message: 'Payment verified and subscription activated'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
