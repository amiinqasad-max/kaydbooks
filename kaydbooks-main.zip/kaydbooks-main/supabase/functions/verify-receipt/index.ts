import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { receipt, platform, userId, plan } = await req.json()

    if (!receipt || !platform || !userId || !plan) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    let isValid = false
    let transactionId = ''

    if (platform === 'ios') {
      // Verify Apple receipt
      const appleResponse = await fetch('https://buy.itunes.apple.com/verifyReceipt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          'receipt-data': receipt,
          'password': Deno.env.get('APPLE_SHARED_SECRET') // Set this in your Supabase environment
        })
      })

      const appleData = await appleResponse.json()
      
      if (appleData.status === 0) {
        isValid = true
        transactionId = appleData.receipt.in_app[0]?.transaction_id || appleData.receipt.transaction_id
      }
    } else if (platform === 'android') {
      // Verify Google Play receipt
      const { google } = await import('https://esm.sh/googleapis@105')
      
      // You need to set up Google Play Developer API credentials
      const auth = new google.auth.GoogleAuth({
        credentials: JSON.parse(Deno.env.get('GOOGLE_SERVICE_ACCOUNT_KEY') || '{}'),
        scopes: ['https://www.googleapis.com/auth/androidpublisher']
      })

      const androidpublisher = google.androidpublisher({ version: 'v3', auth })
      
      try {
        const result = await androidpublisher.purchases.subscriptions.get({
          packageName: 'com.kaydbooks.app', // Your app package name
          subscriptionId: receipt.productId,
          token: receipt.purchaseToken
        })

        if (result.data.purchaseType === 0) { // Test purchase
          isValid = true
          transactionId = receipt.purchaseToken
        }
      } catch (error) {
        console.error('Google Play verification error:', error)
      }
    }

    if (isValid) {
      // Calculate subscription end date
      let subscriptionEnd = new Date()
      
      switch (plan) {
        case 'trial':
          subscriptionEnd.setDate(subscriptionEnd.getDate() + 7)
          break
        case 'monthly':
          subscriptionEnd.setMonth(subscriptionEnd.getMonth() + 1)
          break
        case 'yearly':
          subscriptionEnd.setFullYear(subscriptionEnd.getFullYear() + 1)
          break
      }

      // Update user subscription in database
      const { error: updateError } = await supabaseClient
        .from('users')
        .update({
          premium: true,
          subscription_plan: plan,
          subscription_start: new Date().toISOString(),
          subscription_end: subscriptionEnd.toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', userId)

      if (updateError) {
        throw updateError
      }

      // Log the transaction
      await supabaseClient
        .from('purchase_transactions')
        .insert({
          user_id: userId,
          platform,
          transaction_id: transactionId,
          plan,
          amount: plan === 'trial' ? 0 : (plan === 'monthly' ? 4.99 : 49.99),
          verified: true,
          created_at: new Date().toISOString()
        })

      return new Response(
        JSON.stringify({ success: true, subscriptionEnd: subscriptionEnd.toISOString() }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    } else {
      return new Response(
        JSON.stringify({ error: 'Invalid receipt' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
